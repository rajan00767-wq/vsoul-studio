import numpy as np
from PIL import Image

img = Image.open("outputs/qwen_uniform_fc7db399e_person_qwen_input.png").convert("RGB")
rgb = np.asarray(img)
h, w = rgb.shape[:2]
print("size", w, h)

white = np.all(rgb > 246, axis=2)
# The neck band of interest: rows just below the chin.
for y in range(520, 660, 10):
    row_white = np.flatnonzero(white[y])
    segs = []
    if row_white.size:
        start = prev = row_white[0]
        for x in row_white[1:]:
            if x != prev + 1:
                segs.append((int(start), int(prev)))
                start = x
            prev = x
        segs.append((int(start), int(prev)))
    nonwhite = np.flatnonzero(~white[y])
    print("y", y, "nonwhite span", (int(nonwhite[0]), int(nonwhite[-1])) if nonwhite.size else None,
          "white segs", segs[:8])
