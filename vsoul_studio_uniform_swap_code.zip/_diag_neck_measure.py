"""Print per-row skin fraction below the chin on the identity-conditioning canvas.

Helps choose a measurement rule that survives jaw shadow / beard without
assuming a fixed neck length.
"""
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

from pipelines.photo_restoration import _get_insight_app
from pipelines.qwen_edit_pipeline import QwenEditPipeline

PERSON = Path(
    "uploads/fc7db399-a21a-4fea-9651-bbdc81f666d0_"
    "WhatsApp Image 2026-07-16 at 8.54.48 PM (1).jpeg"
)

detector = _get_insight_app()
person_pil = Image.open(PERSON).convert("RGB")
face = detector.get(cv2.cvtColor(np.asarray(person_pil), cv2.COLOR_RGB2BGR))[0]
canvas = QwenEditPipeline._source_identity_reference(
    person_pil, face.bbox, 800, 1024,
    background_color=None, target_face_fraction=.35,
)
rgb = np.asarray(canvas)
hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
faces = detector.get(cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))
x1, y1, x2, y2 = faces[0].bbox
face_w = x2 - x1
face_h = y2 - y1
half = max(2, int(round(face_w * .16)))
cx = (x1 + x2) * .5
left, right = int(cx - half), int(cx + half)

print("face", [round(v) for v in (x1, y1, x2, y2)], "face_h", round(face_h))
print("row  dy/fh  strict  loose  medianRGB")
for row in range(int(y2) - 4, int(y2 + face_h * .30)):
    band = hsv[row, left:right]
    strict = np.count_nonzero(
        (band[:, 1] >= 20) & (band[:, 2] >= 35) & (band[:, 2] <= 245)
        & ((band[:, 0] <= 25) | (band[:, 0] >= 170))
    ) / max(1, band.shape[0])
    loose = np.count_nonzero(
        (band[:, 1] >= 12) & (band[:, 2] >= 18) & (band[:, 2] <= 250)
        & ((band[:, 0] <= 30) | (band[:, 0] >= 165))
    ) / max(1, band.shape[0])
    med = np.median(rgb[row, left:right], axis=0).astype(int)
    print(f"{row:4d} {((row - y2) / face_h):6.3f}  {strict:.2f}  {loose:.2f}   {med.tolist()}")
