"""Identify where the grey-green wall in the rough-fit conditioning image
comes from: identical pixels => pasted back from the source person image.
"""
from pathlib import Path
import sys

import numpy as np
from PIL import Image

OUT = Path("outputs")
JOB = sys.argv[1] if len(sys.argv) > 1 else "qwen_uniform_fc7db399"

cond = np.asarray(Image.open(OUT / f"{JOB}_selected_bg_conditioning.png").convert("RGB")).astype(int)
src = np.asarray(Image.open(OUT / f"{JOB}_person_qwen_input.png").convert("RGB")).astype(int)
print("cond", cond.shape, "src", src.shape)
h = min(cond.shape[0], src.shape[0])
w = min(cond.shape[1], src.shape[1])
cond, src = cond[:h, :w], src[:h, :w]

r, g, b = cond[:, :, 0], cond[:, :, 1], cond[:, :, 2]
# grey-green wall: not white, not skin, low saturation, mid brightness
mx = cond.max(axis=2)
mn = cond.min(axis=2)
wall = (mx < 235) & (mx > 120) & ((mx - mn) < 40)
# exclude the subject interior by keeping only rows above the shoulders
wall[int(h * 0.62):] = False
print("wall-ish px in conditioning:", int(wall.sum()))

same = np.all(np.abs(cond - src) <= 2, axis=2)
print("wall px identical to source person:", int((wall & same).sum()),
      f"({(wall & same).sum() / max(1, wall.sum()):.1%})")

# Where in the source are those pixels?
ys, xs = np.where(wall & same)
if ys.size:
    print("source-region y range:", int(ys.min()), int(ys.max()),
          " x range:", int(xs.min()), int(xs.max()))

# Distribution of the wall colour in the conditioning vs flat background white
print("mean wall colour:", cond[wall].mean(axis=0).round(1))
print("corner colour:", cond[5, 5], cond[5, -5], cond[-5, 5])
