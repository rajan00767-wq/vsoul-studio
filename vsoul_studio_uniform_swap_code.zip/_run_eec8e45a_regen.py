import os
import sys
from pathlib import Path

# Ensure memory allocations stay defragmented on 8GB GPU
os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

# Redirect stdout and stderr directly to a log file inside Python to avoid PowerShell stderr ErrorRecord interception
log_path = Path("C:/AI/vsoul-studio/_run_eec8e45a_live.log")
log_file = open(log_path, "w", encoding="utf-8", buffering=1)
sys.stdout = log_file
sys.stderr = log_file

import logging
import traceback

# Mirror main.py: the optional `kernels` DLL is blocked on this machine.
import transformers.utils.import_utils as _transformers_import_utils
_transformers_import_utils.is_kernels_available = lambda *a, **k: False

# Keep intermediate artifacts for inspection and verification
os.environ["VSOUL_CLEAN_SUCCESSFUL_UNIFORM_ARTIFACTS"] = "0"

logging.basicConfig(
    stream=sys.stdout,
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)

import gc
import torch
if torch.cuda.is_available():
    torch.cuda.empty_cache()
gc.collect()

try:
    from pipelines.qwen_edit_pipeline import qwen_service

    PERSON = Path("uploads/eec8e45a-9b8c-447b-ba24-65a069e5f80b_WhatsApp Image 2026-07-16 at 8.54.48 PM (1).jpeg")
    UNIFORM = Path("uploads/eec8e45a-9b8c-447b-ba24-65a069e5f80b_Red-Trimmed Plaid School Uniform Shirt.png")
    JOB_ID = "qwen_uniform_eec8e45a"

    def progress(value, description=""):
        print(f"[progress {value}] {description}", flush=True)

    print(f"Starting regeneration for {JOB_ID}...", flush=True)
    out = qwen_service.qwen_vl_image_edit_uniform_swap(
        str(PERSON),
        str(UNIFORM),
        job_id=JOB_ID,
        background_color="white",
        width=560,
        height=720,
        steps=4,
        progress_callback=progress,
    )
    print("REGENERATION_COMPLETE:", out, flush=True)
except Exception as e:
    print(f"ERROR: {e}", flush=True)
    traceback.print_exc(file=sys.stdout)
    sys.exit(1)
finally:
    log_file.flush()
    log_file.close()
