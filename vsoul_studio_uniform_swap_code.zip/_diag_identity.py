"""Diagnostic: measure identity scores on the latest static job outputs."""
import sys
from pathlib import Path
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent))

from pipelines.uniform_review import check_uniform_identity

job = "qwen_uniform_46e3108a"
out = Path("outputs")

person = Image.open(out / f"{job}_person_qwen_input.png").convert("RGB")
raw = Image.open(out / f"{job}_qwen_raw.png").convert("RGB")
locked = Image.open(out / f"{job}_post_identity_lock.png").convert("RGB")

for name, img in (("qwen_raw", raw), ("post_identity_lock", locked)):
    review = check_uniform_identity(person, img, minimum_similarity=0.70, maximum_geometry_rmse=0.050)
    print(f"{name}: accepted={review.get('accepted')} similarity={review.get('similarity'):.4f} "
          f"geometry={review.get('geometry_rmse')} reason={review.get('reason')}")
