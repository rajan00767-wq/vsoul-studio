import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent))
import transformers.utils.import_utils as _ui  # noqa: E402

_ui.is_kernels_available = lambda *a, **k: False

from pipelines.uniform_composite import (  # noqa: E402
    ensure_garment_cutout,
    hide_product_rear_collar,
)

UNIFORM = Path(
    "uploads/fc7db399-a21a-4fea-9651-bbdc81f666d0_"
    "Red-Trimmed Plaid School Uniform Shirt.png"
)

template = ensure_garment_cutout(Image.open(UNIFORM).convert("RGBA"))
rgba = np.asarray(template).copy()
alpha = rgba[:, :, 3].astype(np.uint8)

# Pale piping: garment pixels that are close to white and low saturation.
rgb = rgba[:, :, :3]
hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
piping = (alpha > 32) & (hsv[:, :, 1] < 70) & (hsv[:, :, 2] > 150)
ys, xs = np.nonzero(piping)
print("template", template.size, "garment rows", np.nonzero(alpha.max(axis=1) > 32)[0][[0, -1]])
print("piping pixels", piping.sum(), "y", ys.min(), ys.max(), "x", xs.min(), xs.max())

cleaned, removed = hide_product_rear_collar(template)
na = np.asarray(cleaned)
still = (na[:, :, 3] > 32) & piping
ys2, xs2 = np.nonzero(still)
print("removed", removed)
print("piping left after hide", int(still.sum()))
if still.sum():
    print("  y", ys2.min(), ys2.max(), "x", xs2.min(), xs2.max())

# Render surviving piping on mid grey so it is clearly visible.
preview = np.full(rgba[:, :, :3].shape, 120, dtype=np.uint8)
mask3 = np.repeat((na[:, :, 3] > 32)[:, :, None], 3, axis=2)
preview = np.where(mask3, na[:, :, :3], preview)
out = Image.fromarray(preview.astype(np.uint8))
top = int(np.nonzero(alpha.max(axis=1) > 32)[0][0])
crop = out.crop((0, max(0, top - 10), out.width, min(out.height, top + int(out.height * .22))))
crop = crop.resize((crop.width * 2, crop.height * 2), Image.LANCZOS)
crop.save("outputs/_diag_template_top.png")
print("wrote outputs/_diag_template_top.png", crop.size, "top row", top)
