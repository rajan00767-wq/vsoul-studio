"""Render the exact recovery head-lock config now used by the pipeline and
crop hair + neck zones to confirm the wall halo and neck seam are gone.
"""
import sys
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent))

from pipelines.qwen_edit_pipeline import QwenEditPipeline
from pipelines.schp_service import parse as parse_body_parts
from pipelines.uniform_review import check_uniform_identity

JOB = "qwen_uniform_46e3108a"
OUT = Path("outputs")

source = Image.open(OUT / f"{JOB}_person_qwen_input.png").convert("RGB")
generated = Image.open(OUT / f"{JOB}_qwen_raw.png").convert("RGB")
labels = parse_body_parts(np.asarray(source))["labels"]

result, info = QwenEditPipeline._lock_uniform_source_head(
    source, generated, labels, (255, 255, 255),
    preserve_light_hair_accessories=True,
    ponytail_side="not-applicable-bilateral",
    preserve_source_chroma=True,
    erase_invented_hair=True,
)
review = check_uniform_identity(
    source, result, minimum_similarity=0.70, maximum_geometry_rmse=0.050,
)
result.save(OUT / "_fixed_lock.png")
print(
    f"applied={info.get('applied')} similarity={review.get('similarity'):.4f} "
    f"geometry={review.get('geometry_rmse'):.4f} accepted={review.get('accepted')}"
)

# Wall-halo metric: pale green-grey pixels behind the head band.
arr = np.asarray(result).astype(int)
h, w = arr.shape[:2]
band = arr[int(h * 0.35):int(h * 0.60), :]
r, g, b = band[:, :, 0], band[:, :, 1], band[:, :, 2]
wall = (r > 195) & (r < 252) & (g - r > 2) & (b - r > 0) & (b < 250)
print(f"fixed wall-halo px: {int(wall.sum())}")

# Crops for visual review.
for name, img in (("src", source), ("raw", generated), ("fixed", result)):
    w2, h2 = img.size
    hair = img.crop((int(w2 * 0.10), 0, int(w2 * 0.95), int(h2 * 0.50)))
    hair.resize((hair.width * 2, hair.height * 2), Image.LANCZOS).save(
        OUT / f"_v2_hair_{name}.png",
    )
    neck = img.crop((int(w2 * 0.20), int(h2 * 0.45), int(w2 * 0.80), int(h2 * 0.78)))
    neck.resize((neck.width * 2, neck.height * 2), Image.LANCZOS).save(
        OUT / f"_v2_neck_{name}.png",
    )
    print(f"crops written for {name}")
