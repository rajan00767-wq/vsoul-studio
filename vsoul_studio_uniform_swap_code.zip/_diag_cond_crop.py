from PIL import Image

for job in ("d", "c"):
    name = f"qwen_uniform_fc7db399{job}_selected_bg_conditioning"
    try:
        img = Image.open(f"outputs/{name}.png").convert("RGB")
    except Exception as exc:
        print(name, "missing", exc)
        continue
    w, h = img.size
    crop = img.crop((int(w * .22), int(h * .50), int(w * .80), int(h * .80)))
    crop = crop.resize((crop.width * 2, crop.height * 2), Image.LANCZOS)
    out = f"outputs/_cond_neck_{job}.png"
    crop.save(out)
    print(out, img.size, crop.size)
