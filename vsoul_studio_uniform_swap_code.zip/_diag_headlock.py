"""A/B test the recovery head-lock parameters on the latest failed static job.

Compares preserve_source_chroma True/False (the recovery path currently uses
False) and measures the biometric identity score each produces.
"""
import sys
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent))

from pipelines.qwen_edit_pipeline import QwenEditPipeline
from pipelines.schp_service import parse as parse_body_parts
from pipelines.uniform_review import check_uniform_identity

JOB = "qwen_uniform_46e3108a"
OUT = Path("outputs")

source = Image.open(OUT / f"{JOB}_person_qwen_input.png").convert("RGB")
generated = Image.open(OUT / f"{JOB}_qwen_raw.png").convert("RGB")

labels = parse_body_parts(np.asarray(source))["labels"]
print(f"source size={source.size} generated size={generated.size}")

variants = {
    "baseline (chroma=False, erase=True)": dict(
        preserve_source_chroma=False, erase_invented_hair=True,
    ),
    "chroma=True, erase=True": dict(
        preserve_source_chroma=True, erase_invented_hair=True,
    ),
    "chroma=True, erase=False": dict(
        preserve_source_chroma=True, erase_invented_hair=False,
    ),
}

for name, kwargs in variants.items():
    result, info = QwenEditPipeline._lock_uniform_source_head(
        source, generated, labels, (255, 255, 255),
        preserve_light_hair_accessories=True,
        ponytail_side="not-applicable-bilateral",
        **kwargs,
    )
    review = check_uniform_identity(
        source, result, minimum_similarity=0.70, maximum_geometry_rmse=0.050,
    )
    tag = name.split(" ")[0].replace("(", "").replace(")", "")
    path = OUT / f"_ab_{tag}.png"
    result.save(path)
    print(
        f"{name}: applied={info.get('applied')} "
        f"similarity={review.get('similarity'):.4f} "
        f"geometry={review.get('geometry_rmse'):.4f} "
        f"accepted={review.get('accepted')} -> {path.name}"
    )
