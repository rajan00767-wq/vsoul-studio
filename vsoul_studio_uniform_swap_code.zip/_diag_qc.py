import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent))
import transformers.utils.import_utils as _ui  # noqa: E402

_ui.is_kernels_available = lambda *a, **k: False

from pipelines.photo_restoration import _get_insight_app  # noqa: E402

OUT = Path("outputs")
JOB = sys.argv[1] if len(sys.argv) > 1 else "qwen_uniform_fc7db399e"
TAG = sys.argv[2] if len(sys.argv) > 2 else JOB[-6:]
SOURCE = sys.argv[3] if len(sys.argv) > 3 else None

detector = _get_insight_app()
result_path = OUT / f"{JOB}_uniform.png"
if not result_path.exists():
    raise SystemExit(f"missing {result_path}")

img = Image.open(result_path).convert("RGB")
rgb = np.asarray(img)
face = detector.get(cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))[0]
x1, y1, x2, y2 = face.bbox
fw, fh = x2 - x1, y2 - y1
print("result", result_path.name, img.size, "face", [round(v) for v in (x1, y1, x2, y2)])

regions = {
    "neck": (x1 - fw * .30, y2 - fh * .10, x2 + fw * .30, y2 + fh * .55),
    "ears": (x1 - fw * .45, y1 + fh * .20, x2 + fw * .45, y1 + fh * .78),
    "eyes": (x1 - fw * .05, y1 + fh * .22, x2 + fw * .05, y1 + fh * .50),
}
for name, box in regions.items():
    left, top = max(0, int(box[0])), max(0, int(box[1]))
    right, bottom = min(img.width, int(box[2])), min(img.height, int(box[3]))
    crop = img.crop((left, top, right, bottom))
    scale = max(2, int(880 / max(1, crop.width)))
    crop = crop.resize((crop.width * scale, crop.height * scale), Image.LANCZOS)
    path = OUT / f"_{TAG}_{name}.png"
    crop.save(path)
    print(path.name, crop.size)

# Backdrop purity outside the silhouette.
corner = np.concatenate([
    rgb[:40, :40].reshape(-1, 3), rgb[:40, -40:].reshape(-1, 3),
    rgb[-40:, :40].reshape(-1, 3), rgb[-40:, -40:].reshape(-1, 3),
])
print("backdrop mean", corner.mean(axis=0).round(1).tolist(), "min", corner.min(axis=0).tolist())

if SOURCE:
    src = Image.open(SOURCE).convert("RGB")
    if src.size != img.size:
        src = src.resize(img.size, Image.LANCZOS)
    mosaic = Image.new("RGB", (img.width * 2 + 12, img.height), (235, 235, 235))
    mosaic.paste(src, (0, 0))
    mosaic.paste(img, (img.width + 12, 0))
    path = OUT / f"_{TAG}_source_vs_result.png"
    mosaic.save(path)
    print("wrote", path.name, mosaic.size)
