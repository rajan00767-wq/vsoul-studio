"""Annotate the rough-fit conditioning image with the measured chin, neck and
collar rows so neck/collar placement can be judged visually.
"""
import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw

sys.path.insert(0, str(Path(__file__).parent))
from pipelines.photo_restoration import _get_insight_app  # noqa: E402

OUT = Path("outputs")
JOB = sys.argv[1] if len(sys.argv) > 1 else "qwen_uniform_fc7db399"
det = _get_insight_app()

img = Image.open(OUT / f"{JOB}_selected_bg_conditioning.png").convert("RGB")
arr = np.asarray(img).astype(int)
h, w = arr.shape[:2]
faces = det.get(cv2.cvtColor(np.asarray(img), cv2.COLOR_RGB2BGR))
x1, y1, x2, y2 = faces[0].bbox
fh, fw = y2 - y1, x2 - x1
cx = int((x1 + x2) / 2)

r, g, b = arr[:, :, 0], arr[:, :, 1], arr[:, :, 2]
skin = (r > 60) & (r - g > 12) & (g - b > 6) & (r - b > 18)
white = (r > 245) & (g > 245) & (b > 245)
red = (r > 150) & (r - g > 70) & (r - b > 70)

c0, c1 = cx - int(fw * 0.14), cx + int(fw * 0.14)
neck_bottom = None
for y in range(int(y2), h):
    if skin[y, c0:c1].mean() > 0.6:
        neck_bottom = y
red_top = None
for y in range(int(y2), h):
    if red[y, int(w * 0.2):int(w * 0.8)].sum() > 12:
        red_top = y
        break
white_wedge = 0
for y in range(int(y2), min(h, int(y2 + fh * 0.5))):
    row = white[y, cx - int(fw * 0.42):cx + int(fw * 0.42)]
    wedge = np.flatnonzero(row)
    if wedge.size > fw * 0.06:
        white_wedge += 1

annotated = img.copy()
draw = ImageDraw.Draw(annotated)
for y, colour, label in (
    (int(y2), (255, 60, 60), "chin"),
    (neck_bottom, (60, 200, 120), "neck bottom"),
    (red_top, (80, 140, 255), "collar top"),
):
    if y is None:
        continue
    draw.line([(0, int(y)), (w, int(y))], fill=colour, width=2)
    draw.text((6, max(0, int(y) - 14)), label, fill=colour)

box_top = int(y2 - fh * 0.12)
box_bottom = min(h, int(y2 + fh * 0.55))
left = max(0, cx - int(fw * 0.75))
right = min(w, cx + int(fw * 0.75))
crop = annotated.crop((left, box_top, right, box_bottom))
scale = max(1, int(round(700 / max(1, crop.width))))
crop = crop.resize((crop.width * scale, crop.height * scale), Image.LANCZOS)
crop.save(OUT / "_rough_neck_lines.png")

print(f"chin={y2:.0f} neck_bottom={neck_bottom} collar_top={red_top} face_h={fh:.0f}")
print(
    f"neck_gap={(neck_bottom - y2) / fh if neck_bottom else None} "
    f"collar_gap={(red_top - y2) / fh if red_top else None}"
)
print(f"white wedge rows in neck band: {white_wedge}")
print(f"-> _rough_neck_lines.png {crop.size}")
