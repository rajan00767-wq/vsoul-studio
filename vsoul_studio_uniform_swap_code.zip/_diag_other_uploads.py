from pathlib import Path

from PIL import Image

cases = [
    ("cd255446", "uploads/cd255446-d69c-40c6-bfe2-53faf5d94c0e_"
                 "vecteezy_a-young-indian-schoolboy-in-uniform-isolated-on-white_70919061.PNG"),
    ("b470ffdf", "uploads/b470ffdf-302c-42f6-a548-1a3c46940c98_person.jpeg"),
]
for job, src in cases:
    source = Image.open(src).convert("RGB")
    result_path = Path(f"outputs/qwen_uniform_{job}_uniform.png")
    if not result_path.exists():
        print(job, "no result")
        continue
    result = Image.open(result_path).convert("RGB")
    tile_h = 620
    tiles = []
    for img in (source, result):
        scale = tile_h / img.height
        tiles.append(img.resize((max(1, int(img.width * scale)), tile_h), Image.LANCZOS))
    width = sum(t.width for t in tiles) + 20
    sheet = Image.new("RGB", (width, tile_h), (240, 240, 240))
    x = 0
    for t in tiles:
        sheet.paste(t, (x, 0))
        x += t.width + 20
    out = f"outputs/_cmp_{job}.png"
    sheet.save(out)
    print(out, sheet.size, "source", source.size, "result", result.size)
