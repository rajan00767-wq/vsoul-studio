import os
import sys
import tempfile
import unittest

os.environ["USE_HUB_KERNELS"] = "NO"
os.environ.setdefault("YOLO_CONFIG_DIR", os.path.join(tempfile.gettempdir(), "ultralytics"))
try:
    import onnx
except Exception:
    pass
import transformers.utils.import_utils as _ui

_ui.is_kernels_available = lambda *a, **k: False

if len(sys.argv) > 1:
    suite = unittest.defaultTestLoader.loadTestsFromNames(sys.argv[1:])
else:
    suite = unittest.defaultTestLoader.discover("tests")

result = unittest.TextTestRunner(verbosity=1).run(suite)
sys.exit(0 if result.wasSuccessful() else 1)

