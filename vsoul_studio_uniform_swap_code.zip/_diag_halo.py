"""Locate the pale hair halo: source of Qwen raw vs head-lock paste."""
import sys
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent))

OUT = Path("outputs")
raw = np.asarray(Image.open(OUT / "qwen_uniform_46e3108a_qwen_raw.png").convert("RGB"))
ab = np.asarray(Image.open(OUT / "_ab_baseline.png").convert("RGB"))
src = np.asarray(Image.open(OUT / "qwen_uniform_46e3108a_person_qwen_input.png").convert("RGB"))

print("sizes:", raw.shape, ab.shape, src.shape)

# Halo samples: pale ring around hair (left/right/top of crown) in ab coords.
points = [(160, 120), (640, 150), (420, 40), (700, 400), (140, 400), (415, 950)]
for (x, y) in points:
    print(
        f"({x},{y}) raw={tuple(raw[y, x])} ab={tuple(ab[y, x])}"
    )

# Column scan across left halo at y=300 to find band widths.
row_raw = raw[300, 120:260].astype(int)
row_ab = ab[300, 120:260].astype(int)
print("raw row 300 x120-260 min/max:", row_raw.min(axis=0), row_raw.max(axis=0))
print("ab  row 300 x120-260 min/max:", row_ab.min(axis=0), row_ab.max(axis=0))

# Find halo pixels in ab: greenish-pale (R<G, R<245, near-white-ish) outside hair.
halo = (ab[:, :, 1].astype(int) - ab[:, :, 0].astype(int) > 6) & (ab[:, :, 0] > 170)
print("ab greenish-pale px:", int(halo.sum()))
halo_raw = (raw[:, :, 1].astype(int) - raw[:, :, 0].astype(int) > 6) & (raw[:, :, 0] > 170)
print("raw greenish-pale px:", int(halo_raw.sum()))
ys, xs = np.where(halo)
if len(xs):
    print("ab halo bbox x", xs.min(), xs.max(), "y", ys.min(), ys.max())
    print("ab halo mean color:", ab[ys, xs].mean(axis=0).round(1))
ys2, xs2 = np.where(halo_raw)
if len(xs2):
    print("raw halo mean color:", raw[ys2, xs2].mean(axis=0).round(1))
    print("raw halo bbox x", xs2.min(), xs2.max(), "y", ys2.min(), ys2.max())

# Source wall color (corner sample)
print("src corner:", src[10, 10], src[10, -10])
