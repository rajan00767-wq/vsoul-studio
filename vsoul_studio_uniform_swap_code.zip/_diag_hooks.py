import cv2
import numpy as np
from PIL import Image

rgb = np.asarray(Image.open("outputs/_rough_preview_conditioning.png").convert("RGB"))
h, w = rgb.shape[:2]
mx = rgb.max(axis=2).astype(int)
mn = rgb.min(axis=2).astype(int)
# Pale cream/grey structure: bright, nearly neutral, but NOT the pure white backdrop.
cream = (mn > 185) & ((mx - mn) < 45) & ~((rgb[:, :, 0] > 250) & (rgb[:, :, 1] > 250) & (rgb[:, :, 2] > 250))
cream[:520] = False
cream[760:] = False

count, labels, stats, centroids = cv2.connectedComponentsWithStats(cream.astype(np.uint8), 8)
print("components", count - 1)
for i in range(1, count):
    x, y, cw, ch, area = stats[i]
    if area < 40:
        continue
    print(f"  area {area:5d} bbox x{x}-{x + cw} y{y}-{y + ch} size {cw}x{ch}")

# Where does the garment fabric start per row around the neck?
for row in range(560, 720, 10):
    cols = np.flatnonzero(~((rgb[row, :, 0] > 250) & (rgb[row, :, 1] > 250) & (rgb[row, :, 2] > 250)))
    print("row", row, "non-white x from", int(cols[0]) if cols.size else None,
          "to", int(cols[-1]) if cols.size else None, "count", cols.size)
