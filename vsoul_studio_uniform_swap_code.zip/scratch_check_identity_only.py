from PIL import Image
import numpy as np
import cv2
from pipelines.schp_service import parse as parse_body_parts
from pipelines.uniform_composite import build_rough_composite
from pipelines.photo_restoration import _get_insight_app

person_path = 'uploads/eec8e45a-9b8c-447b-ba24-65a069e5f80b_WhatsApp Image 2026-07-16 at 8.54.48 PM (1).jpeg'
uniform_path = 'uploads/eec8e45a-9b8c-447b-ba24-65a069e5f80b_Red-Trimmed Plaid School Uniform Shirt.png'

person = Image.open(person_path).convert('RGB')
uniform = Image.open(uniform_path).convert('RGBA')

labels = parse_body_parts(np.array(person))['labels']
app = _get_insight_app()
faces = app.get(cv2.cvtColor(np.array(person), cv2.COLOR_RGB2BGR))
face_box = faces[0].bbox

rough, placement = build_rough_composite(person, uniform, labels, face_box, (255, 255, 255))
face_y2 = face_box[3]
face_h = face_box[3] - face_box[1]
face_w = face_box[2] - face_box[0]
face_center_x = (face_box[0] + face_box[2]) * 0.5
raw_neck_ratio = 0.144
collar_neck_seat_y = face_y2 + face_h * max(0.06, raw_neck_ratio)
cx = int(round(face_center_x))

mask_y, mask_x = np.indices(labels.shape)
neck_half_w = face_w * 0.26
neck_skin_corridor = (
    (mask_y >= face_y2 - face_h * 0.02)
    & (mask_y < collar_neck_seat_y)
    & (np.abs(mask_x - face_center_x) <= neck_half_w)
)

torso_clothing_recovery = (
    (mask_y >= collar_neck_seat_y)
    & (labels != 1) & (labels != 2) & (labels != 4)
    & ~neck_skin_corridor
)
source_clothing = np.isin(labels, (5, 6, 7, 8, 9, 10, 11, 12)).astype(np.uint8)
source_clothing[torso_clothing_recovery] = 1

clothing = source_clothing.copy()
clothing[neck_skin_corridor] = 0

collar_top = collar_neck_seat_y - face_h * 0.18
collar_bottom = collar_neck_seat_y + face_h * 0.25
collar_progress = np.clip((mask_y - collar_top) / max(1.0, collar_bottom - collar_top), 0.0, 1.0)
collar_outer_half_width = face_w * (0.38 + 0.08 * collar_progress)
collar_inner_half_width = face_w * (0.20 * np.clip(1.0 - collar_progress * 2.4, 0.0, 1.0))
collar_distance = np.abs(mask_x - face_center_x)
collar_refine_zone = (
    (mask_y >= collar_top)
    & (mask_y <= collar_bottom)
    & (collar_distance <= collar_outer_half_width)
    & (collar_distance >= collar_inner_half_width)
    & ~neck_skin_corridor
)

edit_region = clothing > 0
edit_region |= collar_refine_zone
edit_region &= ~neck_skin_corridor

garment_removal_region = (
    (source_clothing > 0)
    & (mask_y >= face_y2 - face_h * .005)
)
garment_removal_region &= ~neck_skin_corridor

seed_fabric_rgb = np.asarray(rough)
identity_only_rgb = np.array(person).copy()
identity_only_rgb[garment_removal_region] = seed_fabric_rgb[garment_removal_region]

print('identity_only_rgb along cx=452:')
for dy_ratio in [0.0, 0.05, 0.10, 0.14, 0.18, 0.22, 0.26, 0.30, 0.35, 0.40]:
    y = int(face_y2 + dy_ratio * face_h)
    print(f'dy={dy_ratio:.2f} (y={y}): RGB={identity_only_rgb[y, cx]}, in_remov={garment_removal_region[y, cx]}')
