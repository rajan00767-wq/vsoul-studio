"""Re-run job 5a1bbeaa's exact inputs in dynamic mode to check the neck fix.

That job delivered a tripled neck (exposed skin below the chin went from 0.16
to 0.47 face-boxes) because the 700-token prompt was silently truncated past
the encoder's 512-token budget, dropping the neck contract. Same uploads, same
delivery size, dynamic prompt mode (the route default) - the branch the
defect was in. Note: qwen_vl_image_edit_uniform_swap takes no prompt_mode
argument, despite what CLAUDE.md and _run_static_job.py imply.
"""
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)

PERSON = Path(
    "uploads/5a1bbeaa-2fb0-4714-be63-ea5c98396798_"
    "vecteezy_a-young-indian-schoolboy-in-uniform-isolated-on-white_70919061.PNG"
)
UNIFORM = Path(
    "uploads/5a1bbeaa-2fb0-4714-be63-ea5c98396798_"
    "Red-Trimmed Plaid School Uniform Shirt.png"
)
JOB = sys.argv[1] if len(sys.argv) > 1 else "qwen_uniform_neckfix"

# Mirror main.py: the optional `kernels` DLL is blocked on this machine.
import transformers.utils.import_utils as _transformers_import_utils  # noqa: E402

_transformers_import_utils.is_kernels_available = lambda *a, **k: False

from pipelines.qwen_edit_pipeline import qwen_service  # noqa: E402


def progress(value, description=""):
    print(f"[progress {value}] {description}", flush=True)


out = qwen_service.qwen_vl_image_edit_uniform_swap(
    str(PERSON),
    str(UNIFORM),
    job_id=JOB,
    background_color="white",
    width=560,
    height=720,
    steps=4,
    progress_callback=progress,
)
print("RESULT:", out)
