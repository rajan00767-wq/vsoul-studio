"""Crop the hair/crown region from source vs restored output for comparison."""
from pathlib import Path

from PIL import Image

OUT = Path("outputs")
JOB = "qwen_uniform_46e3108a"

for name, fname in (
    ("src", f"{JOB}_person_qwen_input.png"),
    ("raw", f"{JOB}_qwen_raw.png"),
    ("lock", f"{JOB}_post_identity_lock.png"),
):
    img = Image.open(OUT / fname).convert("RGB")
    w, h = img.size
    crop = img.crop((int(w * 0.10), 0, int(w * 0.95), int(h * 0.50)))
    crop = crop.resize((crop.width * 2, crop.height * 2), Image.LANCZOS)
    crop.save(OUT / f"_hair_{name}.png")
    print(f"{name}: -> _hair_{name}.png {crop.size}")
