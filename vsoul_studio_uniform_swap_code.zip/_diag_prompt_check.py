from pipelines.qwen_edit_pipeline import QwenEditPipeline

p = QwenEditPipeline._build_universal_static_uniform_prompt(
    '#FFFFFF', (255, 255, 255), False,
)
print('words', len(p.split()))
q = QwenEditPipeline._build_universal_static_uniform_prompt(
    '#047EF6', (4, 126, 246), True,
    source_age_band='school-age child',
    source_hair_geometry_lock=(
        'preserve exactly 2 tied section(s) on viewer-left and viewer-right; '
        'visible hair reaches 0.45 face-heights below the jaw. '
        'Do not shorten, merge, untie or mirror them.'
    ),
)
print('words2', len(q.split()))
for word in (
    'braid', 'pigtail', 'ponytail', 'flower', 'ribbon', 'boy', 'girl',
    'male', 'female', 'plaid', 'checkered', 'band collar',
):
    assert word not in q.lower(), word
print('no fixture labels OK')
for phrase in (
    'IMAGE 1 is the only person authority',
    'IMAGE 2 is the only uniform authority',
    'is protected source content and is not an edit target',
    'without guessing or naming a hairstyle',
    'Neutralize harsh light',
    'enlarge eyes',
    'narrow the nose',
    "naturally tailored to IMAGE 1's body",
    'preserve exactly 2 tied section(s)',
    '0.45 face-heights below the jaw',
    'same current apparent age',
    'exact flat #047EF6 RGB(4, 126, 246)',
    'complete-crown upper-chest passport frame',
):
    assert phrase in q, phrase
print('contract phrases OK')
print(q)
