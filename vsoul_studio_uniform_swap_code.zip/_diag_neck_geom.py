"""Measure neck length and locate the paste-boundary seam relative to the
face bbox, to confirm the central_torso_zone exclusion cuts the neck."""
from pathlib import Path

import numpy as np
from PIL import Image

import sys
sys.path.insert(0, str(Path(__file__).parent))
from pipelines.photo_restoration import _get_insight_app

OUT = Path("outputs")
JOB = "qwen_uniform_46e3108a"
det = _get_insight_app()


def strict_skin(arr):
    r, g, b = arr[..., 0], arr[..., 1], arr[..., 2]
    return (r > 70) & (r < 245) & (r - g > 10) & (g - b > 8) & (r - b > 20)


def analyse(name, path):
    img = Image.open(path).convert("RGB")
    arr = np.asarray(img).astype(int)
    h, w = arr.shape[:2]
    faces = det.get(cv2_bgr(arr))
    if len(faces) != 1:
        print(f"{name}: face detection failed ({len(faces)})")
        return
    x1, y1, x2, y2 = faces[0].bbox
    face_h = y2 - y1
    # Central neck column band.
    cx0, cx1 = int(w * 0.44), int(w * 0.56)
    skin = strict_skin(arr[:, cx0:cx1, :])
    # Collar top: first row below chin where skin coverage drops below 25%.
    collar = None
    for y in range(int(y2), h):
        if skin[y].mean() < 0.25:
            collar = y
            break
    neck_len = (collar - y2) if collar else None
    # Seam: strongest luma second-derivative in neck zone (chin..collar+40).
    x0, x1c = int(w * 0.40), int(w * 0.60)
    lum = (np.asarray(img).astype(float)[:, x0:x1c, :] @ np.array([0.299, 0.587, 0.114])).mean(axis=1)
    lo = int(y2)
    hi = min(h - 2, (collar + 60) if collar else int(y2 + 250))
    d2 = np.abs(np.diff(lum, 2))
    seam = int(np.argmax(d2[lo:hi])) + lo if hi > lo + 2 else None
    seam_rel = (seam - y2) / face_h if seam else None
    theory = y2 + face_h * 0.10  # central_torso_zone top boundary
    print(
        f"{name}: bbox=({x1:.0f},{y1:.0f},{x2:.0f},{y2:.0f}) face_h={face_h:.0f} "
        f"collar_top={collar} neck_len={neck_len} ({neck_len/face_h:.2f}x face_h) "
        f"seam_y={seam} seam_rel_face_h={seam_rel:.2f} "
        f"theory_central_torso_top={theory:.0f}"
    )


def cv2_bgr(arr):
    import cv2
    return cv2.cvtColor(arr.astype(np.uint8), cv2.COLOR_RGB2BGR)


for name, fname in (
    ("src", f"{JOB}_person_qwen_input.png"),
    ("raw", f"{JOB}_qwen_raw.png"),
    ("lock", f"{JOB}_post_identity_lock.png"),
    ("ab", "_ab_baseline.png"),
):
    analyse(name, OUT / fname)
