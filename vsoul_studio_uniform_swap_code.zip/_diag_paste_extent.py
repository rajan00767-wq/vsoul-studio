"""Diff head-lock output vs Qwen raw per row to find the paste extent,
and locate the visible mid-neck seam relative to it."""
from pathlib import Path

import numpy as np
from PIL import Image

OUT = Path("outputs")
JOB = "qwen_uniform_46e3108a"

raw = np.asarray(Image.open(OUT / f"{JOB}_qwen_raw.png").convert("RGB")).astype(int)
lock = np.asarray(Image.open(OUT / f"{JOB}_post_identity_lock.png").convert("RGB")).astype(int)
h, w = raw.shape[:2]

diff = np.abs(raw - lock).max(axis=2)
changed = diff > 8

# Paste extent per row (central 70% width to skip border noise).
lo, hi = int(w * 0.15), int(w * 0.85)
row_frac = changed[:, lo:hi].mean(axis=1)
paste_rows = np.where(row_frac > 0.05)[0]
print(f"paste extent: y={paste_rows.min()}..{paste_rows.max()} ({paste_rows.min()/h:.3f}..{paste_rows.max()/h:.3f})")

# Gap analysis: rows between face top and collar with low change (pure Qwen).
runs = []
in_run = False
for y in range(int(h * 0.30), int(h * 0.80)):
    if row_frac[y] <= 0.05 and not in_run:
        start, in_run = y, True
    elif row_frac[y] > 0.05 and in_run:
        if y - start > 6:
            runs.append((start, y))
        in_run = False
print("unchanged (pure-Qwen) horizontal bands >6px in 0.30-0.80h:")
for s, e in runs:
    print(f"  y={s}..{e} ({s/h:.3f}..{e/h:.3f}), {e-s}px")

# Neck tonal seam: within central neck column band, find rows where lock's
# row-mean color jumps vs its neighbours (second derivative).
x0, x1 = int(w * 0.40), int(w * 0.60)
neck = lock[:, x0:x1, :].mean(axis=1)          # per-row mean color
lum = neck @ np.array([0.299, 0.587, 0.114])
d2 = np.abs(np.diff(lum, 2))
lo_y, hi_y = int(h * 0.45), int(h * 0.75)
order = np.argsort(d2[lo_y:hi_y])[::-1][:6]
print("lock neck strongest row-to-row luma curvature (seam candidates):")
for i in order:
    y = int(i) + lo_y
    print(f"  y={y} ({y/h:.3f}) d2={d2[y]:.1f} color={neck[y].round(0)} prev={neck[y-1].round(0)} next={neck[y+1].round(0)}")

# Same for raw for comparison.
neck_r = raw[:, x0:x1, :].mean(axis=1)
lum_r = neck_r @ np.array([0.299, 0.587, 0.114])
d2_r = np.abs(np.diff(lum_r, 2))
order_r = np.argsort(d2_r[lo_y:hi_y])[::-1][:4]
print("raw neck strongest seam candidates:")
for i in order_r:
    y = int(i) + lo_y
    print(f"  y={y} ({y/h:.3f}) d2={d2_r[y]:.1f}")
