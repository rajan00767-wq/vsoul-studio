from pathlib import Path

import cv2
import numpy as np
from PIL import Image

from pipelines.photo_restoration import _get_insight_app

OUT = Path("outputs")
JOB = "qwen_uniform_fc7db399e"
detector = _get_insight_app()

img = Image.open(OUT / f"{JOB}_uniform.png").convert("RGB")
rgb = np.asarray(img)
face = detector.get(cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))[0]
x1, y1, x2, y2 = face.bbox
fw, fh = x2 - x1, y2 - y1
print("size", img.size, "face", [round(v) for v in (x1, y1, x2, y2)])

regions = {
    "neck": (x1 - fw * .30, y2 - fh * .10, x2 + fw * .30, y2 + fh * .55),
    "ears": (x1 - fw * .45, y1 + fh * .20, x2 + fw * .45, y1 + fh * .78),
    "eyes": (x1 - fw * .05, y1 + fh * .22, x2 + fw * .05, y1 + fh * .50),
}
for name, box in regions.items():
    left, top = max(0, int(box[0])), max(0, int(box[1]))
    right, bottom = min(img.width, int(box[2])), min(img.height, int(box[3]))
    crop = img.crop((left, top, right, bottom))
    scale = max(2, int(880 / max(1, crop.width)))
    crop = crop.resize((crop.width * scale, crop.height * scale), Image.LANCZOS)
    path = OUT / f"_e_{name}.png"
    crop.save(path)
    print(path, crop.size)

# Sclera redness, same measurement as the earlier failing portrait.
for tag, path in (
    ("e", OUT / f"{JOB}_uniform.png"),
    ("c", OUT / "qwen_uniform_fc7db399c_uniform.png"),
    ("src", Path("uploads/fc7db399-a21a-4fea-9651-bbdc81f666d0_WhatsApp Image 2026-07-16 at 8.54.48 PM (1).jpeg")),
):
    im = Image.open(path).convert("RGB")
    arr = np.asarray(im).astype(int)
    f = detector.get(cv2.cvtColor(np.asarray(im), cv2.COLOR_RGB2BGR))[0]
    fx1, fy1, fx2, fy2 = f.bbox
    fwid, fhei = fx2 - fx1, fy2 - fy1
    for side, cx in (("L", fx1 + fwid * .30), ("R", fx1 + fwid * .70)):
        box = arr[int(fy1 + fhei * .36):int(fy1 + fhei * .46),
                  int(cx - fwid * .10):int(cx + fwid * .10)]
        flat = box.reshape(-1, 3)
        luma = flat.mean(axis=1)
        bright = flat[luma >= np.percentile(luma, 92)]
        mean = bright.mean(axis=0)
        print(f"{tag} sclera {side} mean {mean.round(0).tolist()} redness R-B {mean[0] - mean[2]:.0f}")
