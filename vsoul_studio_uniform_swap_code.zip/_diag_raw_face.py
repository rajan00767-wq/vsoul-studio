from pathlib import Path

import cv2
import numpy as np
from PIL import Image

from pipelines.photo_restoration import _get_insight_app

OUT = Path("outputs")
detector = _get_insight_app()


def ear_and_eye(path, tag):
    image = Image.open(path).convert("RGB")
    rgb = np.asarray(image)
    faces = detector.get(cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))
    if not faces:
        print(tag, "no face")
        return
    x1, y1, x2, y2 = faces[0].bbox
    fw, fh = x2 - x1, y2 - y1
    print(tag, image.size, "face", [round(v) for v in (x1, y1, x2, y2)])
    regions = {
        "ears": (x1 - fw * .50, y1 + fh * .25, x2 + fw * .50, y1 + fh * .80),
        "eyes": (x1 - fw * .05, y1 + fh * .22, x2 + fw * .05, y1 + fh * .50),
    }
    for name, box in regions.items():
        crop = image.crop((
            max(0, int(box[0])), max(0, int(box[1])),
            min(image.width, int(box[2])), min(image.height, int(box[3])),
        ))
        scale = max(2, int(880 / max(1, crop.width)))
        crop = crop.resize((crop.width * scale, crop.height * scale), Image.LANCZOS)
        out = OUT / f"_{tag}_{name}.png"
        crop.save(out)
        print(" ", out, crop.size)


ear_and_eye(OUT / "qwen_uniform_fc7db399d_qwen_raw.png", "draw")
ear_and_eye(OUT / "qwen_uniform_fc7db399c_uniform.png", "cdeliv")
