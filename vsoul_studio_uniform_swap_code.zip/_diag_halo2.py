"""Inspect residual pale halo pixels in the fixed head-lock output, restricted
to the head band (above the shoulders) so the plaid shirt cannot pollute it.
"""
import io
import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent))

OUT = Path("outputs")
JOB = "qwen_uniform_46e3108a"

src = np.asarray(Image.open(OUT / f"{JOB}_person_qwen_input.png").convert("RGB")).astype(int)
fix = np.asarray(Image.open(OUT / "_fixed_lock.png").convert("RGB")).astype(int)
old = np.asarray(Image.open(OUT / "_ab_baseline.png").convert("RGB")).astype(int)

h, w = fix.shape[:2]


def halo_mask(arr, lo=0.30, hi=0.62):
    m = np.zeros(arr.shape[:2], dtype=bool)
    band = arr[int(h * lo):int(h * hi)]
    r, g, b = band[:, :, 0], band[:, :, 1], band[:, :, 2]
    m[int(h * lo):int(h * hi)] = (
        (r > 195) & (r < 253) & (g - r >= 1) & (b - r >= 1) & (g < 253)
    )
    return m


for name, arr in (("baseline(old)", old), ("fixed", fix)):
    m = halo_mask(arr)
    ys, xs = np.nonzero(m)
    print(f"{name}: halo px={int(m.sum())}")
    if len(ys):
        print(f"   mean={arr[m].mean(axis=0).round(1)} bbox x={xs.min()}..{xs.max()} y={ys.min()}..{ys.max()}")

m = halo_mask(fix)
ys, xs = np.nonzero(m)

# Reference: source wall colour from top corners (uint8 for cv2).
edge = 40
corner = np.concatenate((
    src[:edge, :edge].reshape(-1, 3),
    src[:edge, -edge:].reshape(-1, 3),
)).astype(np.uint8)
wall_lab = np.median(cv2.cvtColor(corner.reshape(-1, 1, 3), cv2.COLOR_RGB2LAB), axis=0)
print(f"source wall Lab={wall_lab.round(1)} rgb={corner.mean(axis=0).round(1)}")

# Map halo pixels back to source coordinates.
src_h, src_w = src.shape[:2]
sy = (ys * src_h // h).clip(0, src_h - 1)
sx = (xs * src_w // w).clip(0, src_w - 1)
src_at = src[sy, sx]
src_lum = src_at.mean(axis=1)
print(f"source colour at halo spots: mean={src_at.mean(axis=0).round(1)} "
      f"frac_lum>180={(src_lum > 180).mean():.2f}")

# Source matte alpha there.
try:
    from pipelines.birefnet_service import background_removal
    buf = io.BytesIO()
    Image.open(OUT / f"{JOB}_person_qwen_input.png").convert("RGB").save(buf, format="PNG")
    cut = Image.open(io.BytesIO(background_removal.remove_background(buf.getvalue()))).convert("RGBA")
    a = np.asarray(cut.getchannel("A"))[sy, sx]
    print(f"source matte alpha at halo spots: mean={a.mean():.0f} "
          f"frac>225={(a > 225).mean():.2f} frac<72={(a < 72).mean():.2f}")
except Exception as exc:
    print(f"matte probe failed: {exc}")

# Where are they? Column histogram around the head.
hist_x = np.bincount(xs, minlength=w)
top = np.argsort(hist_x)[::-1][:10]
print("densest halo cols:", sorted((int(c), int(hist_x[c])) for c in top))
