"""Check whether the delivered raw passes the solid-background gate, and what
the corner samples vs halo look like in Lab/HSV, to explain why background
normalization left the pale ring in place.
"""
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

import sys
sys.path.insert(0, str(Path(__file__).parent))
from pipelines.qwen_edit_pipeline import QwenEditPipeline

OUT = Path("outputs")
JOB = "qwen_uniform_46e3108a"
TARGET = (255, 255, 255)

raw = Image.open(OUT / f"{JOB}_qwen_raw.png").convert("RGB")
arr = np.asarray(raw)
h, w = arr.shape[:2]
edge = max(4, min(16, h // 20, w // 20))

lab = cv2.cvtColor(arr, cv2.COLOR_RGB2LAB).astype(np.float32)
corners = np.concatenate((
    lab[:edge, :edge].reshape(-1, 3),
    lab[:edge, -edge:].reshape(-1, 3),
))
bg_lab = np.median(corners, axis=0)
dist = np.linalg.norm(lab - bg_lab, axis=2)
print(f"edge={edge} corner Lab={bg_lab.round(1)}")
print(f"corner rgb mean={arr[:edge,:edge].reshape(-1,3).mean(axis=0).round(1)}")

# Halo pixels (head band ring).
band = arr[int(h * .28):int(h * .64)]
r, g, b = band[:, :, 0], band[:, :, 1], band[:, :, 2]
halo_band = (r > 190) & (r < 252) & (g - r >= 1) & (b - r >= 1) & (g < 252)
halo = np.zeros((h, w), dtype=bool)
halo[int(h * .28):int(h * .64)] = halo_band
print(f"halo px={int(halo.sum())} mean Lab={lab[halo].mean(axis=0).round(1)} "
      f"mean dist-to-corner={dist[halo].mean():.1f} min={dist[halo].min():.1f}")

hsv = cv2.cvtColor(arr, cv2.COLOR_RGB2HSV).astype(np.float32)
corner_hsv = np.median(np.concatenate((
    hsv[:edge, :edge].reshape(-1, 3),
    hsv[:edge, -edge:].reshape(-1, 3),
)), axis=0)
print(f"corner HSV={corner_hsv.round(1)} -> chromatic_backdrop="
      f"{corner_hsv[1] >= 65.0}")
print(f"halo HSV mean={hsv[halo].mean(axis=0).round(1)} "
      f"halo dist<48 frac={float((dist[halo] < 48).mean()):.3f} "
      f"dist<64 frac={float((dist[halo] < 64).mean()):.3f}")

# Does the gate pass (so normalization is skipped)?
try:
    gate = QwenEditPipeline._has_selected_solid_background(
        QwenEditPipeline.__new__(QwenEditPipeline), raw, TARGET,
    )
    print(f"_has_selected_solid_background(raw) = {gate}")
except Exception as exc:
    print(f"gate call failed: {type(exc).__name__}: {exc}")

# Local texture of halo (is it flat?).
gray = cv2.cvtColor(arr, cv2.COLOR_RGB2GRAY).astype(np.float32)
lm = cv2.GaussianBlur(gray, (0, 0), 3.0)
lsm = cv2.GaussianBlur(gray * gray, (0, 0), 3.0)
tex = np.sqrt(np.maximum(0.0, lsm - lm * lm))
print(f"halo local_texture mean={tex[halo].mean():.2f} p90={np.percentile(tex[halo],90):.2f}")

# Is halo semantic background per SCHP?
from pipelines.schp_service import parse as parse_body_parts
labels = parse_body_parts(arr)["labels"]
vals, counts = np.unique(labels[halo], return_counts=True)
print("SCHP labels at halo:", dict(zip(vals.tolist(), (counts * 100 // max(1, counts.sum())).tolist())))
