"""High-zoom hairline/crown comparison: source vs head-locked output.

The VL reviewer claims a 'parting down the middle'. Determine whether the
paste edge or a genuine silhouette change causes that.
"""
from pathlib import Path

from PIL import Image, ImageDraw

OUT = Path("outputs")
JOB = "qwen_uniform_46e3108a"

items = [
    ("SOURCE", OUT / f"{JOB}_person_qwen_input.png"),
    ("HEAD LOCKED", OUT / "_fixed_lock.png"),
]

pad, label_h = 12, 24
crops = []
for label, path in items:
    img = Image.open(path).convert("RGB")
    w, h = img.size
    # Forehead + hairline + crown band.
    crop = img.crop((int(w * 0.24), int(h * 0.10), int(w * 0.76), int(h * 0.42)))
    crop = crop.resize((640, int(640 * crop.height / crop.width)), Image.LANCZOS)
    crops.append((label, crop))

total_w = sum(c.width for _, c in crops) + pad * (len(crops) + 1)
total_h = max(c.height for _, c in crops) + label_h + pad * 2
sheet = Image.new("RGB", (total_w, total_h), (24, 24, 28))
draw = ImageDraw.Draw(sheet)
x = pad
for label, crop in crops:
    draw.text((x + 4, 5), label, fill=(255, 235, 120))
    sheet.paste(crop, (x, label_h + 2))
    x += crop.width + pad
sheet.save(OUT / "_compare_hairline.png")
print(f"saved _compare_hairline.png {sheet.size}")
