import sys
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent))
import transformers.utils.import_utils as _ui  # noqa: E402

_ui.is_kernels_available = lambda *a, **k: False

from pipelines.qwen_edit_pipeline import qwen_service  # noqa: E402
from pipelines.schp_service import parse as parse_body_parts  # noqa: E402
from pipelines.uniform_review import check_uniform_identity  # noqa: E402

SRC = Path(
    "uploads/cd255446-d69c-40c6-bfe2-53faf5d94c0e_"
    "vecteezy_a-young-indian-schoolboy-in-uniform-isolated-on-white_70919061.PNG"
)
RESULT = Path("outputs/qwen_uniform_cd255446g_uniform.png")

source = Image.open(SRC).convert("RGB")
result = Image.open(RESULT).convert("RGB")
labels = parse_body_parts(np.asarray(source))["labels"]
print("source", source.size, "labels", labels.shape)

locked, info = qwen_service._lock_uniform_source_head(
    source,
    result,
    labels,
    (255, 255, 255),
    preserve_light_hair_accessories=True,
    ponytail_side="not-applicable-bilateral",
    erase_invented_hair=True,
    preserve_source_chroma=True,
)
print("info", info)
if info.get("applied"):
    review = check_uniform_identity(source, locked, minimum_similarity=.70, maximum_geometry_rmse=.05)
    print("after", {k: round(v, 4) if isinstance(v, float) else v for k, v in review.items() if k != "initial_review"})
    locked.save("outputs/_diag_cdg_headlock.png")
    print("wrote outputs/_diag_cdg_headlock.png")
