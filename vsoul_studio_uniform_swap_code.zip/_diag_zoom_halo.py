from PIL import Image

box = (150, 380, 430, 560)
for tag, path in (
    ("g_plain", "outputs/qwen_uniform_cd255446g_uniform.png"),
    ("g_locked", "outputs/_diag_cdg_headlock2.png"),
):
    img = Image.open(path).convert("RGB")
    crop = img.crop(box)
    crop = crop.resize((crop.width * 3, crop.height * 3), Image.LANCZOS)
    out = f"outputs/_zoom_{tag}_shoulder.png"
    crop.save(out)
    print(out, crop.size)

hair = (150, 40, 420, 200)
for tag, path in (
    ("g_plain", "outputs/qwen_uniform_cd255446g_uniform.png"),
    ("g_locked", "outputs/_diag_cdg_headlock2.png"),
):
    img = Image.open(path).convert("RGB")
    crop = img.crop(hair)
    crop = crop.resize((crop.width * 3, crop.height * 3), Image.LANCZOS)
    out = f"outputs/_zoom_{tag}_hair.png"
    crop.save(out)
    print(out, crop.size)
