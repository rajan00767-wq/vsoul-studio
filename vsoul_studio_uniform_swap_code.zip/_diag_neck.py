"""Crop the neck/jaw/collar region from each pipeline stage for visual review."""
from pathlib import Path

from PIL import Image

OUT = Path("outputs")
JOB = "qwen_uniform_46e3108a"

images = {
    "src": OUT / f"{JOB}_person_qwen_input.png",
    "raw": OUT / f"{JOB}_qwen_raw.png",
    "lock": OUT / f"{JOB}_post_identity_lock.png",
    "ab": OUT / "_ab_baseline.png",
}

for name, path in images.items():
    img = Image.open(path).convert("RGB")
    w, h = img.size
    # Neck + jaw + collar band: middle-lower head area.
    crop = img.crop((int(w * 0.20), int(h * 0.45), int(w * 0.80), int(h * 0.75)))
    crop = crop.resize((crop.width * 2, crop.height * 2), Image.LANCZOS)
    out = OUT / f"_neck_{name}.png"
    crop.save(out)
    print(f"{name}: {path.name} size={img.size} -> {out.name}")
