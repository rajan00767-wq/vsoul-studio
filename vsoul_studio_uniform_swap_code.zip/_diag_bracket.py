import numpy as np
from PIL import Image

rgb = np.asarray(Image.open("outputs/_rough_preview_conditioning.png").convert("RGB"))
print("shape", rgb.shape)
for name, (cx, cy) in {
    "left-bracket": (352, 620),
    "right-bracket": (655, 620),
    "neck-centre": (500, 640),
}.items():
    patch = rgb[cy - 12:cy + 12, cx - 12:cx + 12].reshape(-1, 3)
    colours, counts = np.unique(patch, axis=0, return_counts=True)
    order = np.argsort(-counts)[:5]
    print(name, [(colours[i].tolist(), int(counts[i])) for i in order])
