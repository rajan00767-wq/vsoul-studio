from PIL import Image
import numpy as np
import cv2
from pipelines.schp_service import parse as parse_body_parts
from pipelines.uniform_composite import build_rough_composite
from pipelines.photo_restoration import _get_insight_app

person_path = 'uploads/eec8e45a-9b8c-447b-ba24-65a069e5f80b_WhatsApp Image 2026-07-16 at 8.54.48 PM (1).jpeg'
uniform_path = 'uploads/eec8e45a-9b8c-447b-ba24-65a069e5f80b_Red-Trimmed Plaid School Uniform Shirt.png'

person = Image.open(person_path).convert('RGB')
uniform = Image.open(uniform_path).convert('RGBA')

labels = parse_body_parts(np.array(person))['labels']
app = _get_insight_app()
faces = app.get(cv2.cvtColor(np.array(person), cv2.COLOR_RGB2BGR))
face_box = faces[0].bbox

rough, placement = build_rough_composite(person, uniform, labels, face_box, (255, 255, 255))
face_y2 = face_box[3]
face_h = face_box[3] - face_box[1]
face_w = face_box[2] - face_box[0]
face_center_x = (face_box[0] + face_box[2]) * 0.5
raw_neck_ratio = float(placement.get('neck_seat_ratio') or 0.20)
print('raw_neck_ratio:', raw_neck_ratio)
collar_neck_seat_y = face_y2 + face_h * max(0.06, raw_neck_ratio)
print('collar_neck_seat_y:', collar_neck_seat_y, 'chin_y:', face_y2)

# Check what labels exist between face_y2 and collar_neck_seat_y + 0.3 * face_h
cx = int(round(face_center_x))
for dy_ratio in [0.0, 0.05, 0.10, 0.14, 0.18, 0.22, 0.26, 0.30, 0.35, 0.40]:
    y = int(face_y2 + dy_ratio * face_h)
    print(f'dy={dy_ratio:.2f} (y={y}, cx={cx}): label={labels[y, cx]}, RGB={np.array(person)[y, cx]}')
