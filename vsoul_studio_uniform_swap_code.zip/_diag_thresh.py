"""Measure the true pale halo's Lab distance / saturation / texture vs the
white target, to pick a safe candidate threshold for interior cleanup.
"""
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

OUT = Path("outputs")
JOB = "qwen_uniform_46e3108a"

for tag, fname in (("raw", f"{JOB}_qwen_raw.png"), ("locked", f"{JOB}_post_identity_lock.png")):
    rgb = np.asarray(Image.open(OUT / fname).convert("RGB"), dtype=np.uint8)
    h, w = rgb.shape[:2]
    target = np.asarray([255, 255, 255], dtype=np.uint8)
    target_lab = cv2.cvtColor(target.reshape(1, 1, 3), cv2.COLOR_RGB2LAB)[0, 0].astype(np.float32)
    lab = cv2.cvtColor(rgb, cv2.COLOR_RGB2LAB).astype(np.float32)
    dist = np.linalg.norm(lab - target_lab, axis=2)
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV).astype(np.float32)
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY).astype(np.float32)
    mean = cv2.GaussianBlur(gray, (0, 0), 2.2)
    sq = cv2.GaussianBlur(gray * gray, (0, 0), 2.2)
    texture = np.sqrt(np.maximum(0.0, sq - mean * mean))

    # True pale halo: head band, pale green-grey, not white, not skin.
    band = np.zeros((h, w), dtype=bool)
    band[int(h * .28):int(h * .64)] = True
    r = rgb[:, :, 0].astype(int)
    g = rgb[:, :, 1].astype(int)
    b = rgb[:, :, 2].astype(int)
    pale = band & (r > 190) & (r < 253) & (g - r >= 1) & (b - r >= 1) & (g < 253)
    # Exclude near-pure-white (already correct).
    pale &= ~((r >= 250) & (g >= 250) & (b >= 250))

    n = int(pale.sum())
    print(f"\n{tag}: halo px={n}")
    if n:
        d, s, t = dist[pale], hsv[:, :, 1][ pale], texture[pale]
        print(f"  Lab distance to white: mean={d.mean():.1f} p50={np.percentile(d,50):.1f} "
              f"p90={np.percentile(d,90):.1f} max={d.max():.1f}")
        print(f"  HSV S: mean={s.mean():.1f} p90={np.percentile(s,90):.1f}")
        print(f"  texture: mean={t.mean():.2f} p90={np.percentile(t,90):.2f} p99={np.percentile(t,99):.2f}")
        for thr in (40, 50, 60, 70, 80):
            print(f"    dist<={thr}: {float((d <= thr).mean()):.3f}", end="")
        print()
        # What would the strict candidate test capture?
        cand = (d <= 40.0) & (hsv[:, :, 1][pale] <= 50.0) & (t <= 10.0)
        print(f"  strict candidates (d<=40 & S<=50 & tex<=10): {float(cand.mean()):.3f}")
        cand2 = (d <= 70.0) & (hsv[:, :, 1][pale] <= 60.0) & (t <= 14.0)
        print(f"  relaxed candidates (d<=70 & S<=60 & tex<=14): {float(cand2.mean()):.3f}")

    # Also measure: is the halo connected to the border through candidate pixels?
    # Approximate: flood from border over pixels with dist<=70 & tex<=14.
    passable = (dist <= 70.0) & (texture <= 14.0) & (hsv[:, :, 1] <= 60.0)
    seeds = np.zeros((h, w), dtype=bool)
    seeds[0, :] = passable[0, :]
    seeds[-1, :] = passable[-1, :]
    seeds[:, 0] = passable[:, 0]
    seeds[:, -1] = passable[:, -1]
    # Iterative dilation limited to passable region.
    reached = seeds.copy()
    for _ in range(max(h, w)):
        grown = cv2.dilate(reached.astype(np.uint8), np.ones((3, 3), np.uint8)) > 0
        grown &= passable
        if grown.sum() == reached.sum():
            break
        reached = grown
    print(f"  halo reachable from border through relaxed candidates: "
          f"{float((pale & reached).sum()) / max(1, n):.3f}")
