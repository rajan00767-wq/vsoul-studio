import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent))
import transformers.utils.import_utils as _ui  # noqa: E402

_ui.is_kernels_available = lambda *a, **k: False

from pipelines.photo_restoration import PhotoRestorationService  # noqa: E402
from pipelines.uniform_review import check_uniform_identity  # noqa: E402

SRC = Path(
    "uploads/cd255446-d69c-40c6-bfe2-53faf5d94c0e_"
    "vecteezy_a-young-indian-schoolboy-in-uniform-isolated-on-white_70919061.PNG"
)
RESULT = Path("outputs/qwen_uniform_cd255446_uniform.png")

source = Image.open(SRC).convert("RGB")
result = Image.open(RESULT).convert("RGB")
print("sizes", source.size, result.size)

before = check_uniform_identity(source, result, minimum_similarity=.70, maximum_geometry_rmse=.05)
print("before", {k: round(v, 4) if isinstance(v, float) else v for k, v in before.items() if k != 'initial_review'})

locked = PhotoRestorationService.lock_face_keep_clothes(source, result, strength=.88)
print("locked returned", None if locked is None else locked.size)
if locked is not None:
    after = check_uniform_identity(source, locked, minimum_similarity=.70, maximum_geometry_rmse=.05)
    print("after", {k: round(v, 4) if isinstance(v, float) else v for k, v in after.items() if k != 'initial_review'})
    locked.save("outputs/_diag_cd_locked.png")
    print("wrote outputs/_diag_cd_locked.png")
