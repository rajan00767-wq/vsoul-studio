from pathlib import Path

import numpy as np
from PIL import Image

OUT = Path("outputs")
cand = sorted(OUT.glob("qwen_uniform_fc7db399c*conditioning*.png"))
print("c conditioning files", [p.name for p in cand])
for p in cand:
    img = Image.open(p).convert("RGB")
    print(p.name, img.size)

# Compare the neck region of the earlier validated run's guide against the new one.
for p in cand + [OUT / "_rough_preview_conditioning.png"]:
    img = Image.open(p).convert("RGB")
    w, h = img.size
    box = (int(w * .22), int(h * .50), int(w * .80), int(h * .80))
    crop = img.crop(box)
    crop = crop.resize((crop.width * 2, crop.height * 2), Image.LANCZOS)
    out = OUT / f"_cmpneck_{p.stem}.png"
    crop.save(out)
    print(out, crop.size)
