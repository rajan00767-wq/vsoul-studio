"""Run one real static_test uniform swap with the current working-tree code.

Uses the exact uploads from job fc7db399 so the rough-fit neck/collar and
background behaviour can be compared against the reported failure.
"""
import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)

PERSON = Path(
    "uploads/fc7db399-a21a-4fea-9651-bbdc81f666d0_"
    "WhatsApp Image 2026-07-16 at 8.54.48 PM (1).jpeg"
)
UNIFORM = Path(
    "uploads/fc7db399-a21a-4fea-9651-bbdc81f666d0_"
    "Red-Trimmed Plaid School Uniform Shirt.png"
)
JOB = sys.argv[1] if len(sys.argv) > 1 else "qwen_uniform_fc7db399b"
if len(sys.argv) > 3:
    PERSON = Path(sys.argv[2])
    UNIFORM = Path(sys.argv[3])

# Mirror main.py: an Application Control policy blocks the optional `kernels`
# DLL on this machine, and the failed import would mask the real run.
import transformers.utils.import_utils as _transformers_import_utils  # noqa: E402

_transformers_import_utils.is_kernels_available = lambda *a, **k: False

from pipelines.qwen_edit_pipeline import qwen_service  # noqa: E402


def progress(value, description=""):
    print(f"[progress {value}] {description}", flush=True)


out = qwen_service.qwen_vl_image_edit_uniform_swap(
    str(PERSON),
    str(UNIFORM),
    job_id=JOB,
    background_color="white",
    width=560,
    height=720,
    steps=20,
    progress_callback=progress,
    prompt_mode="static_test",
)
print("RESULT:", out)
