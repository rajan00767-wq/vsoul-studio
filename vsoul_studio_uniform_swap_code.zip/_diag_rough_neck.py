"""Zoom the neck-to-collar junction of the rough-fit conditioning image to
show exactly how the appended neck meets the fitted collar.
"""
from pathlib import Path
import sys

from PIL import Image, ImageDraw

OUT = Path("outputs")
JOB = sys.argv[1] if len(sys.argv) > 1 else "qwen_uniform_fc7db399"

img = Image.open(OUT / f"{JOB}_selected_bg_conditioning.png").convert("RGB")
w, h = img.size
print(f"conditioning size: {img.size}")

# Neck + collar band.
crop = img.crop((int(w * 0.25), int(h * 0.50), int(w * 0.78), int(h * 0.82)))
crop = crop.resize((crop.width * 2, crop.height * 2), Image.LANCZOS)
crop.save(OUT / "_rough_neck.png")
print(f"-> _rough_neck.png {crop.size}")

# Source person for reference at the same band.
src = Image.open(OUT / f"{JOB}_person_qwen_input.png").convert("RGB")
sw, sh = src.size
scrop = src.crop((int(sw * 0.25), int(sh * 0.50), int(sw * 0.78), int(sh * 0.82)))
scrop = scrop.resize((crop.width, crop.height), Image.LANCZOS)

pad, label_h = 12, 24
sheet = Image.new("RGB", (crop.width + scrop.width + pad * 3, crop.height + label_h + pad * 2), (24, 24, 28))
draw = ImageDraw.Draw(sheet)
draw.text((pad, 5), "SOURCE PERSON", fill=(255, 235, 120))
sheet.paste(scrop, (pad, label_h + 2))
draw.text((crop.width + pad * 2, 5), "ROUGH FIT CONDITIONING", fill=(255, 235, 120))
sheet.paste(crop, (crop.width + pad * 2, label_h + 2))
sheet.save(OUT / "_rough_neck_compare.png")
print(f"-> _rough_neck_compare.png {sheet.size}")
