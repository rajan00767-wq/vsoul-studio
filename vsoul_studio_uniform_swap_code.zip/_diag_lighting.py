"""Compare lighting and detail between the uploaded photo and a delivered job.

Reports the studio-lighting signals (evenness, shadow strength, backdrop
shadow, highlight clipping) and a sharpness proxy for both images.
"""
import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent))

from pipelines.photo_restoration import _get_insight_app  # noqa: E402

JOB = sys.argv[1] if len(sys.argv) > 1 else "qwen_uniform_fc7db399c"
OUT = Path("outputs")
SOURCE = Path(
    "uploads/fc7db399-a21a-4fea-9651-bbdc81f666d0_"
    "WhatsApp Image 2026-07-16 at 8.54.48 PM (1).jpeg"
)

detector = _get_insight_app()


def report(name, path):
    image = Image.open(path).convert("RGB")
    rgb = np.asarray(image)
    faces = detector.get(cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))
    if not faces:
        print(name, 'no face')
        return
    x1, y1, x2, y2 = faces[0].bbox
    fw, fh = x2 - x1, y2 - y1
    cx = (x1 + x2) / 2
    luma = cv2.cvtColor(rgb, cv2.COLOR_RGB2LAB)[:, :, 0].astype(np.float32)

    # Cheeks: a band below the eyes, split left/right, avoiding hair.
    band_top = int(y1 + fh * .48)
    band_bottom = int(y1 + fh * .78)
    left = luma[band_top:band_bottom, int(cx - fw * .30):int(cx - fw * .10)]
    right = luma[band_top:band_bottom, int(cx + fw * .10):int(cx + fw * .30)]
    forehead = luma[int(y1 + fh * .10):int(y1 + fh * .26), int(cx - fw * .18):int(cx + fw * .18)]
    chin = luma[int(y1 + fh * .80):int(y1 + fh * .94), int(cx - fw * .16):int(cx + fw * .16)]

    # Backdrop: two patches beside the head.
    side_y = slice(int(y1 + fh * .10), int(y1 + fh * .60))
    left_bg = rgb[side_y, :max(4, int(x1 - fw * .10))]
    right_bg = rgb[side_y, min(rgb.shape[1] - 4, int(x2 + fw * .10)):]
    backdrop = np.concatenate([left_bg.reshape(-1, 3), right_bg.reshape(-1, 3)])
    backdrop_luma = cv2.cvtColor(
        backdrop.reshape(-1, 1, 3), cv2.COLOR_RGB2LAB,
    )[:, :, 0].astype(np.float32)

    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    eye_band = gray[int(y1 + fh * .18):int(y1 + fh * .50),
                    int(cx - fw * .35):int(cx + fw * .35)]
    sharpness = float(cv2.Laplacian(eye_band, cv2.CV_32F).var())

    print(f'{name} ({image.size[0]}x{image.size[1]})')
    print(f'  cheek L/R  {left.mean():.1f} / {right.mean():.1f}'
          f'  asymmetry {abs(left.mean() - right.mean()):.1f}')
    print(f'  forehead {forehead.mean():.1f}  chin {chin.mean():.1f}'
          f'  falloff {forehead.mean() - chin.mean():+.1f}')
    print(f'  face std {luma[int(y1):int(y2), int(x1):int(x2)].std():.1f}')
    print(f'  backdrop mean {backdrop_luma.mean():.1f} std {backdrop_luma.std():.2f}'
          f'  min {backdrop_luma.min():.0f}')
    print(f'  highlight clipped {(luma[int(y1):int(y2), int(x1):int(x2)] >= 250).mean() * 100:.2f}%')
    print(f'  sharpness proxy {sharpness:.0f}')


report('SOURCE', SOURCE)
report('DELIVERED', OUT / f'{JOB}_uniform.png')
