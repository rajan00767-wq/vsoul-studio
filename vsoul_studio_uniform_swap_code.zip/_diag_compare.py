"""Side-by-side face comparison: source vs raw Qwen vs head-locked output.

Determines whether the VL identity_changed / hair_changed flags describe real
pixel defects or reviewer false positives on an already-restored head.
"""
from pathlib import Path

from PIL import Image, ImageDraw

OUT = Path("outputs")
JOB = "qwen_uniform_46e3108a"

items = [
    ("SOURCE", OUT / f"{JOB}_person_qwen_input.png"),
    ("QWEN RAW", OUT / f"{JOB}_qwen_raw.png"),
    ("HEAD LOCKED", OUT / f"{JOB}_post_identity_lock.png"),
]

crops = []
for label, path in items:
    img = Image.open(path).convert("RGB")
    w, h = img.size
    # Head region: top through just below chin.
    crop = img.crop((int(w * 0.14), int(h * 0.02), int(w * 0.86), int(h * 0.60)))
    crop = crop.resize((420, int(420 * crop.height / crop.width)), Image.LANCZOS)
    crops.append((label, crop))

pad = 14
label_h = 26
total_w = sum(c.width for _, c in crops) + pad * (len(crops) + 1)
total_h = max(c.height for _, c in crops) + label_h + pad * 2
sheet = Image.new("RGB", (total_w, total_h), (24, 24, 28))
draw = ImageDraw.Draw(sheet)
x = pad
for label, crop in crops:
    draw.text((x + 4, 6), label, fill=(255, 235, 120))
    sheet.paste(crop, (x, label_h + 4))
    x += crop.width + pad

sheet.save(OUT / "_compare_faces.png")
print(f"saved _compare_faces.png {sheet.size}")

# Also a hair-only strip at higher zoom.
hair_crops = []
for label, path in items:
    img = Image.open(path).convert("RGB")
    w, h = img.size
    crop = img.crop((int(w * 0.18), int(h * 0.01), int(w * 0.84), int(h * 0.36)))
    crop = crop.resize((460, int(460 * crop.height / crop.width)), Image.LANCZOS)
    hair_crops.append((label, crop))

total_w = sum(c.width for _, c in hair_crops) + pad * (len(hair_crops) + 1)
total_h = max(c.height for _, c in hair_crops) + label_h + pad * 2
sheet2 = Image.new("RGB", (total_w, total_h), (24, 24, 28))
draw2 = ImageDraw.Draw(sheet2)
x = pad
for label, crop in hair_crops:
    draw2.text((x + 4, 6), label, fill=(255, 235, 120))
    sheet2.paste(crop, (x, label_h + 4))
    x += crop.width + pad
sheet2.save(OUT / "_compare_hair.png")
print(f"saved _compare_hair.png {sheet2.size}")
