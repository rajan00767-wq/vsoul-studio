import transformers.utils.import_utils as _ui

_ui.is_kernels_available = lambda *a, **k: False

from pipelines.qwen_edit_pipeline import MODELS_DIR, QwenEditPipeline
from transformers import AutoTokenizer

prompt = QwenEditPipeline._build_universal_static_uniform_prompt(
    '#FFFFFF', (255, 255, 255), False,
)
tokenizer = AutoTokenizer.from_pretrained((MODELS_DIR / 'tokenizer').as_posix())
for label, text in (
    ('no age', prompt),
    ('age', QwenEditPipeline._build_universal_static_uniform_prompt(
        '#FFFFFF', (255, 255, 255), False, source_age_band='school-age child',
    )),
    ('age+light', QwenEditPipeline._build_universal_static_uniform_prompt(
        '#FFFFFF', (255, 255, 255), True, source_age_band='school-age child',
    )),
):
    ids = tokenizer(text, add_special_tokens=False)['input_ids']
    print(label, 'words', len(text.split()), 'tokens', len(ids), 'budget 512')
