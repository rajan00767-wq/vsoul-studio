"""Rebuild only the rough-fit conditioning image (no diffusion).

Mirrors the pipeline's static_test preparation: identity-conditioning crop,
parser matte onto the selected flat backdrop, then the rough garment fit.
Writes ``outputs/_rough_preview_conditioning.png`` and a neck close-up so the
per-person collar/neck geometry can be judged without a full Qwen run.
"""
import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent))

# Mirror main.py: an Application Control policy blocks the optional `kernels`
# DLL on this machine, and import failure would mask every conditioning run.
import transformers.utils.import_utils as _transformers_import_utils  # noqa: E402

_transformers_import_utils.is_kernels_available = lambda *a, **k: False

from pipelines.photo_restoration import _get_insight_app  # noqa: E402
from pipelines.qwen_edit_pipeline import QwenEditPipeline  # noqa: E402
from pipelines.schp_service import parse as parse_body_parts  # noqa: E402
from pipelines.uniform_composite import (  # noqa: E402
    build_rough_composite,
    ensure_garment_cutout,
    hide_product_rear_collar,
)

OUT = Path("outputs")
PERSON = Path(
    "uploads/fc7db399-a21a-4fea-9651-bbdc81f666d0_"
    "WhatsApp Image 2026-07-16 at 8.54.48 PM (1).jpeg"
)
UNIFORM = Path(
    "uploads/fc7db399-a21a-4fea-9651-bbdc81f666d0_"
    "Red-Trimmed Plaid School Uniform Shirt.png"
)
BACKDROP = (255, 255, 255)

detector = _get_insight_app()
person_pil = Image.open(PERSON).convert("RGB")
source_face = detector.get(cv2.cvtColor(np.asarray(person_pil), cv2.COLOR_RGB2BGR))[0]

conditioning = QwenEditPipeline._source_identity_reference(
    person_pil,
    source_face.bbox,
    800,
    1024,
    background_color=None,
    target_face_fraction=.35,
)

labels = parse_body_parts(np.asarray(conditioning.convert("RGB")))["labels"]
person_mask = (labels != 0).astype(np.uint8)
# Mirror the pipeline: LIP-20 labels the bare neck as background, so recover the
# photographed neck skin below the jaw before matting.
_cond_face = detector.get(
    cv2.cvtColor(np.asarray(conditioning.convert("RGB")), cv2.COLOR_RGB2BGR)
)[0].bbox
_cx = (_cond_face[0] + _cond_face[2]) * .5
_fw = _cond_face[2] - _cond_face[0]
_fh = _cond_face[3] - _cond_face[1]
_rows, _cols = np.indices(person_mask.shape)
_corr = (
    (np.abs(_cols - _cx) <= _fw * .26)
    & (_rows >= int(_cond_face[3]) - 2)
    & (_rows <= int(_cond_face[3] + _fh * .30))
)
_hsv = cv2.cvtColor(np.asarray(conditioning.convert("RGB")), cv2.COLOR_RGB2HSV)
_skin = (
    (_hsv[:, :, 1] >= 20)
    & (_hsv[:, :, 2] >= 30)
    & (_hsv[:, :, 2] <= 245)
    & ((_hsv[:, :, 0] <= 25) | (_hsv[:, :, 0] >= 170))
)
person_mask = np.maximum(person_mask, (_corr & _skin).astype(np.uint8))
person_mask = cv2.morphologyEx(
    person_mask, cv2.MORPH_CLOSE,
    cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5)), iterations=1,
)
# Mirror the pipeline: close background islands enclosed by the silhouette
# (the parser punches the neck/collar gap white, which reads as a notch).
_mask_bytes = (person_mask * 255).astype(np.uint8)
_padded = cv2.copyMakeBorder(
    _mask_bytes, 1, 1, 1, 1, cv2.BORDER_CONSTANT, value=0,
)
_flooded = _padded.copy()
cv2.floodFill(
    _flooded,
    np.zeros((_flooded.shape[0] + 2, _flooded.shape[1] + 2), np.uint8),
    (0, 0), 255,
)
_enclosed = (_flooded == 0)[1:-1, 1:-1]
if np.any(_enclosed):
    _band = (
        (_rows >= int(_cond_face[3]) - 2)
        & (_rows <= int(_cond_face[3] + _fh * .45))
        & (np.abs(_cols - _cx) <= _fw * .42)
    )
    person_mask = np.maximum(person_mask, (_enclosed & _band).astype(np.uint8))
person_mask = cv2.dilate(
    person_mask, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3)), iterations=1,
)
matte = np.clip(
    cv2.GaussianBlur(person_mask.astype(np.float32), (0, 0), 1.1) * 1.35,
    0.0, 1.0,
)[:, :, None]
base = np.asarray(conditioning.convert("RGB"), dtype=np.float32)
rough_source = Image.fromarray(
    np.rint(base * matte + np.asarray(BACKDROP, dtype=np.float32) * (1 - matte))
    .clip(0, 255).astype(np.uint8),
    "RGB",
)

rough_labels = parse_body_parts(np.asarray(rough_source))["labels"]
rough_face = detector.get(
    cv2.cvtColor(np.asarray(rough_source), cv2.COLOR_RGB2BGR)
)[0]
rough_source.save(OUT / "_rough_preview_source.png")

template = ensure_garment_cutout(Image.open(UNIFORM).convert("RGBA"))
template, rear_pixels = hide_product_rear_collar(template)
print("hidden rear-collar pixels", rear_pixels)
result, meta = build_rough_composite(
    rough_source,
    template,
    rough_labels,
    rough_face.bbox,
    BACKDROP,
    minimum_neck_gap_ratio=0.0,
)
result.save(OUT / "_rough_preview_conditioning.png")
print("garment_box", meta["garment_box"])
for key in (
    "neck_seat_ratio", "neck_column_half_px",
    "garment_neck_opening_half_px", "source_neck_gap_ratio",
):
    print(f"  {key} = {meta[key]}")

x1, y1, x2, y2 = rough_face.bbox
width, height = result.size
crop = result.crop((
    max(0, int(x1 - (x2 - x1) * .30)),
    max(0, int(y2 - (y2 - y1) * .30)),
    min(width, int(x2 + (x2 - x1) * .30)),
    min(height, int(y2 + (y2 - y1) * .55)),
))
crop = crop.resize((crop.width * 2, crop.height * 2), Image.LANCZOS)
crop.save(OUT / "_rough_preview_neck.png")
print("->", OUT / "_rough_preview_conditioning.png", result.size)
