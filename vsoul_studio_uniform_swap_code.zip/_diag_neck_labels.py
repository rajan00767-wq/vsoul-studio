"""Probe SCHP labels + person matte on the source to see why the neck is
excluded from the head-lock paste (the mid-neck seam)."""
import sys
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent))
from pipelines.schp_service import parse as parse_body_parts

OUT = Path("outputs")
JOB = "qwen_uniform_46e3108a"

src = Image.open(OUT / f"{JOB}_person_qwen_input.png").convert("RGB")
arr = np.asarray(src)
h, w = arr.shape[:2]
labels = parse_body_parts(arr)["labels"]

# Face bbox from earlier probe: (243,172,554,586).
x1, y1, x2, y2 = 243, 172, 554, 586
face_h = y2 - y1

# Sample the neck: below chin, central column, above shirt.
samples = []
for frac in (1.05, 1.2, 1.4, 1.6, 1.8):
    y = int(y2 + face_h * 0.10 * frac / 1.0)  # y2 + face_h*0.10..0.18
    y = int(y2 + face_h * (0.10 * frac))
    if y >= h:
        break
    row = labels[y, int(w * 0.44):int(w * 0.56)]
    vals, counts = np.unique(row, return_counts=True)
    top = sorted(zip(vals, counts), key=lambda t: -t[1])[:4]
    samples.append((y, top))
print("neck rows label distribution (label:count):")
for y, top in samples:
    print(f"  y={y}: {top}")

# What label covers rows y2..y2+0.3*face_h centrally?
zone = labels[int(y2):int(y2 + face_h * 0.30), int(w * 0.44):int(w * 0.56)]
vals, counts = np.unique(zone, return_counts=True)
print("chin+0.30fh zone:", sorted(zip(vals, counts), key=lambda t: -t[1]))

# SCHP class names if available.
try:
    from pipelines.schp_service import LIP_CLASSES
    print("classes:", LIP_CLASSES)
except Exception as exc:
    print("no LIP_CLASSES:", exc)

# BiRefNet matte alpha over the same zone.
try:
    import io
    from pipelines.birefnet_service import background_removal
    from PIL import Image as I
    with io.BytesIO() as buf:
        src.save(buf, format="PNG")
        cutout = I.open(io.BytesIO(background_removal.remove_background(buf.getvalue()))).convert("RGBA")
    alpha = np.asarray(cutout.getchannel("A"))
    az = alpha[int(y2):int(y2 + face_h * 0.30), int(w * 0.44):int(w * 0.56)]
    print(f"matte alpha in chin+0.30fh neck zone: mean={az.mean():.1f} frac>72={(az>72).mean():.2f} frac>16={(az>16).mean():.2f}")
    # And where is the source's own collar (shirt) row?
    for frac in (0.20, 0.25, 0.30, 0.35, 0.40):
        y = int(y2 + face_h * frac)
        if y < h:
            print(f"  y=y2+{frac:.2f}fh={y}: alpha_mean={alpha[y, int(w*0.44):int(w*0.56)].mean():.0f} "
                  f"labels={np.unique(labels[y, int(w*0.44):int(w*0.56)], return_counts=True)}")
except Exception as exc:
    print("matte probe failed:", exc)
