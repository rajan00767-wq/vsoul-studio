import numpy as np
from PIL import Image

box = (270, 540, 540, 620)
for name in ("_rough_preview_conditioning", "_rough_preview_source"):
    img = Image.open(f"outputs/{name}.png").convert("RGB")
    crop = img.crop(box)
    crop = crop.resize((crop.width * 6, crop.height * 6), Image.NEAREST)
    out = f"outputs/{name}_hookzoom.png"
    crop.save(out)
    print(out, crop.size, img.size)

rgb = np.asarray(Image.open("outputs/_rough_preview_conditioning.png").convert("RGB"))
for y in range(566, 600, 4):
    row = rgb[y]
    nz = np.flatnonzero(~np.all(row > 250, axis=1))
    if not nz.size:
        continue
    segs = []
    start = nz[0]
    prev = nz[0]
    for x in nz[1:]:
        if x != prev + 1:
            segs.append((int(start), int(prev)))
            start = x
        prev = x
    segs.append((int(start), int(prev)))
    print("y", y, [(a, b, row[(a + b) // 2].tolist()) for a, b in segs][:6])
