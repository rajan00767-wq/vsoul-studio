"""Compare the pale halo ring across pipeline stages in the head band only.

Qwen's raw output may already carry an off-white backdrop; the head-lock paste
may add source wall. This separates the two.
"""
from pathlib import Path

import numpy as np
from PIL import Image

OUT = Path("outputs")
JOB = "qwen_uniform_46e3108a"

stages = {
    "src": OUT / f"{JOB}_person_qwen_input.png",
    "raw": OUT / f"{JOB}_qwen_raw.png",
    "old_lock": OUT / f"{JOB}_post_identity_lock.png",
    "fixed": OUT / "_fixed_lock.png",
}

LO, HI = 0.28, 0.64  # head band, above shoulders

for name, path in stages.items():
    arr = np.asarray(Image.open(path).convert("RGB")).astype(int)
    h, w = arr.shape[:2]
    band = arr[int(h * LO):int(h * HI)]
    r, g, b = band[:, :, 0], band[:, :, 1], band[:, :, 2]
    # Pale non-white backdrop (green-grey cast), excludes true white and skin.
    pale = (r > 190) & (r < 252) & (g - r >= 1) & (b - r >= 1) & (g < 252)
    # Exclude near-white (>250) which is the intended studio field.
    ys, xs = np.nonzero(pale)
    print(f"{name}: pale-backdrop px={int(pale.sum())}", end="")
    if len(ys):
        # Restrict to a ring around the head: within central 70% width.
        sel = (xs > w * 0.12) & (xs < w * 0.88)
        print(
            f" central={int(sel.sum())} mean={arr[int(h*LO):int(h*HI)][pale].mean(axis=0).round(1)}"
            f" bbox x={xs.min()}..{xs.max()} y={ys.min()+int(h*LO)}..{ys.max()+int(h*LO)}",
            end="",
        )
    print()

# Direct A/B: raw vs fixed pixel diff in the head band, ring region.
raw = np.asarray(Image.open(stages["raw"]).convert("RGB")).astype(int)
fix = np.asarray(Image.open(stages["fixed"]).convert("RGB")).astype(int)
h, w = raw.shape[:2]
diff = np.abs(raw - fix).max(axis=2)
band = np.zeros((h, w), dtype=bool)
band[int(h * LO):int(h * HI)] = True
changed = (diff > 8) & band
print(f"\nraw->fixed changed px in head band: {int(changed.sum())}")
# Of those changed pixels, how many are pale in FIXED (paste added wall)?
r, g, b = fix[:, :, 0], fix[:, :, 1], fix[:, :, 2]
pale_fix = (r > 190) & (r < 252) & (g - r >= 1) & (b - r >= 1) & (g < 252)
print(f"changed AND pale in fixed: {int((changed & pale_fix).sum())}")
# And how many pale pixels already existed in raw at those spots?
r2, g2, b2 = raw[:, :, 0], raw[:, :, 1], raw[:, :, 2]
pale_raw = (r2 > 190) & (r2 < 252) & (g2 - r2 >= 1) & (b2 - r2 >= 1) & (g2 < 252)
print(f"pale in raw (head band): {int((pale_raw & band).sum())}")
print(f"pale in fixed (head band): {int((pale_fix & band).sum())}")
print(f"pale in both: {int((pale_raw & pale_fix & band).sum())}")
print(f"pale ONLY in fixed (paste introduced): {int((pale_fix & ~pale_raw & band).sum())}")
print(f"pale ONLY in raw (paste removed): {int((pale_raw & ~pale_fix & band).sum())}")
