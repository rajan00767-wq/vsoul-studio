"""Measure the central skin column below the chin and the first central
clothing row on a portrait, in face-relative units.
"""
import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent))
from pipelines.photo_restoration import _get_insight_app  # noqa: E402

path = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(
    "outputs/qwen_uniform_fc7db399b_person_qwen_input.png"
)
img = Image.open(path).convert("RGB")
arr = np.asarray(img)
h, w = arr.shape[:2]
faces = _get_insight_app().get(cv2.cvtColor(arr, cv2.COLOR_RGB2BGR))
x1, y1, x2, y2 = faces[0].bbox
fh, fw = y2 - y1, x2 - x1
cx = (x1 + x2) * .5

rgb = arr.astype(int)
r, g, b = rgb[:, :, 0], rgb[:, :, 1], rgb[:, :, 2]
hsv = cv2.cvtColor(arr, cv2.COLOR_RGB2HSV)
skin = (
    (hsv[:, :, 1] >= 20) & (hsv[:, :, 2] >= 35) & (hsv[:, :, 2] <= 245)
    & ((hsv[:, :, 0] <= 25) | (hsv[:, :, 0] >= 170))
    & (r - g > 10)
)

for half in (0.14, 0.20, 0.26):
    c0, c1 = int(cx - fw * half), int(cx + fw * half)
    rows = []
    for y in range(int(y2), min(h, int(y2 + fh * .45))):
        if skin[y, c0:c1].mean() > 0.55:
            rows.append(y)
    print(
        f"half={half:.2f}: skin rows {rows[0] if rows else None}..{rows[-1] if rows else None} "
        f"gap={(rows[-1] - y2) / fh if rows else None}"
    )

print(f"face=({x1:.0f},{y1:.0f},{x2:.0f},{y2:.0f}) fh={fh:.1f} fw={fw:.1f}")
