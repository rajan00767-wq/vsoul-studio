import sys
from pathlib import Path

import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent))

from pipelines.uniform_composite import (  # noqa: E402
    ensure_garment_cutout,
    hide_product_rear_collar,
)

UNIFORM = Path(
    "uploads/cd255446-d69c-40c6-bfe2-53faf5d94c0e_"
    "Red-Trimmed Plaid School Uniform Shirt.png"
)
template = ensure_garment_cutout(Image.open(UNIFORM).convert("RGBA"))
cleaned, removed = hide_product_rear_collar(template)
print("removed", removed)

arr = np.asarray(cleaned).astype(np.float32)
alpha = arr[:, :, 3:4] / 255.0
flat = arr[:, :, :3] * alpha + 255.0 * (1 - alpha)
white = Image.fromarray(np.rint(flat).clip(0, 255).astype(np.uint8), "RGB")
top = int(np.nonzero(np.asarray(cleaned)[:, :, 3].max(axis=1) > 8)[0][0])
bottom = min(white.height, top + int(white.height * .30))
crop = white.crop((0, max(0, top - 8), white.width, bottom))
crop = crop.resize((int(crop.width * 1.2), int(crop.height * 1.2)), Image.LANCZOS)
out = "outputs/_diag_reference_top.png"
crop.save(out)
print("wrote", out, crop.size)
