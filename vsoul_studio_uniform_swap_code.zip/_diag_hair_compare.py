import numpy as np
from PIL import Image

pairs = [
    ("source", "outputs/qwen_uniform_fc7db399e_person_qwen_input.png"),
    ("d_failed", "outputs/qwen_uniform_fc7db399d_post_identity_lock.png"),
    ("c_good", "outputs/qwen_uniform_fc7db399c_uniform.png"),
]
tiles = []
for tag, path in pairs:
    img = Image.open(path).convert("RGB")
    w, h = img.size
    # Head region: top 55% of the frame, centred.
    crop = img.crop((int(w * .12), 0, int(w * .88), int(h * .60)))
    crop = crop.resize((420, int(420 * crop.height / crop.width)), Image.LANCZOS)
    tiles.append((tag, crop))

height = max(t.height for _, t in tiles)
sheet = Image.new("RGB", (420 * len(tiles), height), (255, 255, 255))
for i, (tag, tile) in enumerate(tiles):
    sheet.paste(tile, (420 * i, 0))
    print(i, tag, tile.size)
sheet.save("outputs/_diag_hair_compare.png")
print("wrote outputs/_diag_hair_compare.png", sheet.size)
