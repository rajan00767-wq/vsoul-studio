"""Local SCHP model package."""
