"""Locate the neck seam boundary and measure chin-to-collar neck length.

The identity-lock crop shows a horizontal tonal seam across mid-neck where
the source-head paste ends and Qwen's generated neck begins, plus a pale
green-grey wall halo behind the jaw. This pinpoints the seam row and the
jaw-to-collar distance per stage.
"""
from pathlib import Path

import numpy as np
from PIL import Image

OUT = Path("outputs")
JOB = "qwen_uniform_46e3108a"

paths = {
    "src": OUT / f"{JOB}_person_qwen_input.png",
    "raw": OUT / f"{JOB}_qwen_raw.png",
    "lock": OUT / f"{JOB}_post_identity_lock.png",
    "ab": OUT / "_ab_baseline.png",
}


def analyse(name, path):
    arr = np.asarray(Image.open(path).convert("RGB")).astype(int)
    h, w = arr.shape[:2]
    x0, x1 = int(w * 0.42), int(w * 0.58)
    band = arr[:, x0:x1, :]

    # Skin mask in the central band.
    r, g, b = band[:, :, 0], band[:, :, 1], band[:, :, 2]
    skin = (r > 70) & (r < 245) & (r - b > 15) & (r - g > 4)
    rows = skin.mean(axis=1)

    # Jaw top: first row (from top, after face start) where >70% skin for a
    # sustained run within the head region; collar top: first row after that
    # where skin drops below 35% and stays (shirt takes over).
    skin_rows = rows > 0.70
    # Find the sustained skin run covering the neck (search from 30% height).
    start = int(h * 0.30)
    run_start = None
    for y in range(start, h - 4):
        if skin_rows[y] and run_start is None:
            run_start = y
        elif not skin_rows[y] and run_start is not None:
            if y - run_start > int(h * 0.04):
                break
            run_start = None
    run_end = y
    # Collapse: jaw = last row above run_end with strong chin shadow?
    # Simpler: neck length = collar_top - chin_top where chin_top estimated
    # as run_start + 0.35*run (face occupies upper part of the skin run).
    # Report raw numbers instead.
    # Seam: max row-to-row mean-luma gradient inside the neck run.
    luma = (0.299 * r + 0.587 * g + 0.114 * b).mean(axis=1)
    grad = np.abs(np.diff(luma))
    seg_lo, seg_hi = run_start, run_end
    seam_local = int(np.argmax(grad[seg_lo:seg_hi])) + seg_lo
    print(
        f"{name}: skin run y={run_start}..{run_end} (len={run_end - run_start}, "
        f"{(run_end - run_start) / h:.3f} of h), "
        f"max-gradient row={seam_local} ({seam_local / h:.3f}) "
        f"grad={grad[seam_local]:.1f}, mean grad in run={grad[seg_lo:seg_hi].mean():.1f}"
    )
    # Second-strongest gradient away from the max to see if seam is unique.
    order = np.argsort(grad[seg_lo:seg_hi])[::-1]
    tops = [(int(i) + seg_lo, round(float(grad[int(i) + seg_lo]), 1)) for i in order[:4]]
    print(f"   top gradients (row, val): {tops}")


for name, path in paths.items():
    analyse(name, path)

# Collar top detection: first row from top where central pixels stop being
# skin and become shirt (blue for src, red/blue plaid for outputs).
print("\nCollar top (first non-skin row below 50% height, central 16%):")
for name, path in paths.items():
    arr = np.asarray(Image.open(path).convert("RGB")).astype(int)
    h, w = arr.shape[:2]
    x0, x1 = int(w * 0.42), int(w * 0.58)
    for y in range(int(h * 0.50), h):
        px = arr[y, x0:x1]
        r, g, b = px[:, 0], px[:, 1], px[:, 2]
        skin = (r > 70) & (r - b > 15) & (r - g > 4)
        if skin.mean() < 0.30:
            print(f"  {name}: collar top y={y} ({y / h:.3f})")
            break
