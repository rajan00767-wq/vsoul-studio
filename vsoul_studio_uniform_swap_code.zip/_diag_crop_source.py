from PIL import Image

img = Image.open("outputs/_rough_preview_source.png").convert("RGB")
w, h = img.size
crop = img.crop((int(w * .22), int(h * .50), int(w * .80), int(h * .80)))
crop = crop.resize((crop.width * 2, crop.height * 2), Image.LANCZOS)
crop.save("outputs/_rough_preview_source_neck.png")
print(img.size, crop.size)
