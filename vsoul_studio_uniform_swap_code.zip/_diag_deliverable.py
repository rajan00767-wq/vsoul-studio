"""Report the delivered-portrait quality signals for one job id.

Prints backdrop purity, identity similarity against the untouched upload and
the count of non-backdrop pixels hugging the head silhouette (halo proxy).
"""
import sys
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

sys.path.insert(0, str(Path(__file__).parent))

from pipelines.photo_restoration import _get_insight_app  # noqa: E402

JOB = sys.argv[1] if len(sys.argv) > 1 else "qwen_uniform_fc7db399d"
OUT = Path("outputs")
PERSON = Path(
    "uploads/fc7db399-a21a-4fea-9651-bbdc81f666d0_"
    "WhatsApp Image 2026-07-16 at 8.54.48 PM (1).jpeg"
)

result = Image.open(OUT / f"{JOB}_uniform.png").convert("RGB")
rgb = np.asarray(result).astype(np.float32)
height, width = rgb.shape[:2]
print("size", result.size)

corners = np.concatenate([
    rgb[:24, :24].reshape(-1, 3), rgb[:24, -24:].reshape(-1, 3),
    rgb[-24:, :24].reshape(-1, 3), rgb[-24:, -24:].reshape(-1, 3),
])
print("corner median", np.median(corners, axis=0).astype(int).tolist())

backdrop = np.median(corners, axis=0)
distance = np.linalg.norm(rgb - backdrop[None, None, :], axis=2)
border = np.concatenate([
    distance[:40].ravel(), distance[-40:].ravel(),
    distance[:, :40].ravel(), distance[:, -40:].ravel(),
])
print("backdrop share on border %.4f" % float(np.mean(border <= 18.0)))

detector = _get_insight_app()
faces = detector.get(cv2.cvtColor(np.asarray(result), cv2.COLOR_RGB2BGR))
x1, y1, x2, y2 = faces[0].bbox
print("face", [round(v) for v in (x1, y1, x2, y2)])

source = Image.open(PERSON).convert("RGB")
source_faces = detector.get(cv2.cvtColor(np.asarray(source), cv2.COLOR_RGB2BGR))
from insightface.utils import face_align  # noqa: E402

source_face = source_faces[0]
result_face = faces[0]
source_aligned = face_align.norm_crop(np.asarray(source), landmark=source_face.kps)
result_aligned = face_align.norm_crop(np.asarray(result), landmark=result_face.kps)
recognizer = detector.models.get("recognition")
if recognizer is not None:
    embed_source = recognizer.get_feat(source_aligned)[0]
    embed_result = recognizer.get_feat(result_aligned)[0]
    similarity = float(
        np.dot(embed_source, embed_result)
        / (np.linalg.norm(embed_source) * np.linalg.norm(embed_result))
    )
    print("identity similarity %.4f" % similarity)

# Halo proxy: non-backdrop pixels in a thin ring outside the hair/head region
# that are not part of the uniform's upper width.
skin_or_hair = distance > 18.0
ring_top = max(0, int(y1 - (y2 - y1) * .55))
ring_bottom = int(y1 + (y2 - y1) * .35)
ring_left = max(0, int(x1 - (x2 - x1) * .55))
ring_right = min(width, int(x2 + (x2 - x1) * .55))
ring = skin_or_hair[ring_top:ring_bottom, ring_left:ring_right]
print("head-ring non-backdrop px", int(np.count_nonzero(ring)))
