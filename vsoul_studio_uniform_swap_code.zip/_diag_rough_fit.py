"""Measure chin, neck bottom and garment-collar top in the source portrait vs
the rough-fit conditioning image, to quantify the neck/collar misplacement.
"""
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

import sys
sys.path.insert(0, str(Path(__file__).parent))
from pipelines.photo_restoration import _get_insight_app

OUT = Path("outputs")
JOB = sys.argv[1] if len(sys.argv) > 1 else "qwen_uniform_fc7db399"
det = _get_insight_app()


def measure(name, path):
    img = Image.open(path).convert("RGB")
    arr = np.asarray(img).astype(int)
    h, w = arr.shape[:2]
    faces = det.get(cv2.cvtColor(np.asarray(img), cv2.COLOR_RGB2BGR))
    x1, y1, x2, y2 = faces[0].bbox
    fh, fw = y2 - y1, x2 - x1
    cx = int((x1 + x2) / 2)

    r, g, b = arr[:, :, 0], arr[:, :, 1], arr[:, :, 2]
    skin = (r > 60) & (r - g > 12) & (g - b > 6) & (r - b > 18)
    white = (r > 240) & (g > 240) & (b > 240)

    # Central neck column.
    c0, c1 = cx - int(fw * 0.14), cx + int(fw * 0.14)

    # Neck bottom: last row below chin with >60% skin in the central column.
    neck_bottom = None
    for y in range(int(y2), h):
        if skin[y, c0:c1].mean() > 0.6:
            neck_bottom = y

    # Garment top: first row below chin where the central column stops being
    # skin AND stops being white (shirt/collar takes over).
    garment_top = None
    for y in range(int(y2), h):
        frac_skin = skin[y, c0:c1].mean()
        frac_white = white[y, c0:c1].mean()
        if frac_skin < 0.30 and frac_white < 0.55:
            garment_top = y
            break

    # White gap rows between neck bottom and garment top in the SIDE columns
    # (beside the neck) - these are the wedges the user sees.
    s0, s1 = cx - int(fw * 0.34), cx - int(fw * 0.16)
    s2, s3 = cx + int(fw * 0.16), cx + int(fw * 0.34)
    side = np.concatenate([
        white[int(y2):int(y2 + fh * 0.75), s0:s1],
        white[int(y2):int(y2 + fh * 0.75), s2:s3],
    ], axis=1)
    side_white_frac = side.mean()

    # Red-collar top (rough fit only): first row below chin with strong red
    # anywhere in the central 60% width.
    red = (r > 150) & (r - g > 70) & (r - b > 70)
    red_top = None
    for y in range(int(y2), h):
        if red[y, int(w * 0.2):int(w * 0.8)].sum() > 12:
            red_top = y
            break

    print(
        f"{name}: face=({x1:.0f},{y1:.0f},{x2:.0f},{y2:.0f}) fh={fh:.0f}\n"
        f"   chin={y2:.0f} neck_bottom={neck_bottom} "
        f"gap_chin_to_neckbottom={(neck_bottom - y2) if neck_bottom else None} "
        f"({((neck_bottom - y2) / fh):.3f} fh)\n"
        f"   garment_top={garment_top} "
        f"gap_chin_to_garment={(garment_top - y2) if garment_top else None} "
        f"({((garment_top - y2) / fh):.3f} fh)\n"
        f"   red_collar_top={red_top} "
        f"side_white_frac={side_white_frac:.3f}"
    )
    return dict(chin=y2, fh=fh, neck_bottom=neck_bottom, garment_top=garment_top,
                red_top=red_top, side_white=side_white_frac)


src = measure("SOURCE", OUT / f"{JOB}_person_qwen_input.png")
rough = measure("ROUGH FIT", OUT / f"{JOB}_selected_bg_conditioning.png")

print("\n--- deltas (rough fit relative to source) ---")
for key in ("neck_bottom", "garment_top", "red_top"):
    if src.get(key) and rough.get(key):
        d = rough[key] - src[key]
        print(f"  {key}: {d:+d} px  ({d / src['fh']:+.3f} face heights)")
print(f"  side white fraction: source={src['side_white']:.3f} rough={rough['side_white']:.3f}")
if src.get("neck_bottom") and rough.get("garment_top"):
    gap = rough["garment_top"] - rough["neck_bottom"]
    print(f"  rough fit neck_bottom -> garment_top gap = {gap} px "
          f"({gap / rough['fh']:+.3f} fh)  [positive = white hole]")
