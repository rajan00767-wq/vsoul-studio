from pathlib import Path

import cv2
import numpy as np
from PIL import Image

from pipelines.photo_restoration import _get_insight_app

OUT = Path("outputs")
detector = _get_insight_app()


def ear_crops(path, tag, scale=4):
    image = Image.open(path).convert("RGB")
    rgb = np.asarray(image)
    face = detector.get(cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))[0]
    x1, y1, x2, y2 = face.bbox
    fw, fh = x2 - x1, y2 - y1
    boxes = {
        "ear_left": (x1 - fw * .45, y1 + fh * .28, x1 + fw * .22, y1 + fh * .72),
        "ear_right": (x2 - fw * .22, y1 + fh * .28, x2 + fw * .45, y1 + fh * .72),
    }
    for name, box in boxes.items():
        crop = image.crop((
            max(0, int(box[0])), max(0, int(box[1])),
            min(image.width, int(box[2])), min(image.height, int(box[3])),
        ))
        crop = crop.resize((crop.width * scale, crop.height * scale), Image.LANCZOS)
        out = OUT / f"_{tag}_{name}.png"
        crop.save(out)
        print(tag, name, crop.size)


ear_crops(OUT / "qwen_uniform_fc7db399d_post_identity_lock.png", "d")
ear_crops(OUT / "qwen_uniform_fc7db399d_selected_bg_conditioning.png", "dcond")
ear_crops(OUT / "qwen_uniform_fc7db399c_uniform.png", "c")

# Sclera redness: brightest quartile inside each eye box.
def sclera(path, tag):
    image = Image.open(path).convert("RGB")
    rgb = np.asarray(image).astype(int)
    face = detector.get(cv2.cvtColor(np.asarray(image), cv2.COLOR_RGB2BGR))[0]
    x1, y1, x2, y2 = face.bbox
    fw, fh = x2 - x1, y2 - y1
    for side, cx in (("L", x1 + fw * .30), ("R", x1 + fw * .70)):
        box = rgb[
            int(y1 + fh * .36):int(y1 + fh * .46),
            int(cx - fw * .10):int(cx + fw * .10),
        ]
        flat = box.reshape(-1, 3)
        luma = flat.mean(axis=1)
        bright = flat[luma >= np.percentile(luma, 92)]
        mean = bright.mean(axis=0)
        print(f"{tag} sclera {side} mean {mean.round(0).tolist()} redness R-B {(mean[0] - mean[2]):.0f}")


for path, tag in (
    (OUT / "qwen_uniform_fc7db399d_post_identity_lock.png", "d"),
    (OUT / "qwen_uniform_fc7db399c_uniform.png", "c"),
    (Path("uploads/fc7db399-a21a-4fea-9651-bbdc81f666d0_WhatsApp Image 2026-07-16 at 8.54.48 PM (1).jpeg"), "src"),
):
    try:
        sclera(path, tag)
    except Exception as exc:
        print(tag, "skip", exc)
