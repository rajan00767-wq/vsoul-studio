from pathlib import Path

import cv2
import numpy as np
from PIL import Image

from pipelines.photo_restoration import _get_insight_app

OUT = Path("outputs")
detector = _get_insight_app()


def crops(job, tag):
    image = Image.open(OUT / f"{job}_post_identity_lock.png").convert("RGB")
    rgb = np.asarray(image)
    face = detector.get(cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR))[0]
    x1, y1, x2, y2 = face.bbox
    fw, fh = x2 - x1, y2 - y1
    regions = {
        "eyes": (x1 - fw * .10, y1 + fh * .18, x2 + fw * .10, y1 + fh * .52),
        "ears": (x1 - fw * .55, y1 + fh * .20, x2 + fw * .55, y1 + fh * .78),
        "mouth": (x1 + fw * .10, y1 + fh * .55, x2 - fw * .10, y1 + fh * .95),
    }
    print(tag, "face", [round(v) for v in (x1, y1, x2, y2)], "size", image.size)
    for name, box in regions.items():
        left = max(0, int(box[0]))
        top = max(0, int(box[1]))
        right = min(image.width, int(box[2]))
        bottom = min(image.height, int(box[3]))
        crop = image.crop((left, top, right, bottom))
        scale = max(2, int(900 / max(1, crop.width)))
        crop = crop.resize((crop.width * scale, crop.height * scale), Image.LANCZOS)
        path = OUT / f"_{tag}_{name}.png"
        crop.save(path)
        print(" ", path, crop.size)


crops("qwen_uniform_fc7db399d", "d")
crops("qwen_uniform_fc7db399c", "c")
