"""Measure chin, shoulder/collar line and visible-neck length precisely in
source vs generated output, plus map the head-lock paste boundary."""
from pathlib import Path

import cv2
import numpy as np
from PIL import Image

import sys
sys.path.insert(0, str(Path(__file__).parent))
from pipelines.photo_restoration import _get_insight_app

OUT = Path("outputs")
JOB = "qwen_uniform_46e3108a"
det = _get_insight_app()


def analyse(name, path):
    img = Image.open(path).convert("RGB")
    arr = np.asarray(img).astype(int)
    h, w = arr.shape[:2]
    faces = det.get(cv2.cvtColor(arr.astype(np.uint8), cv2.COLOR_RGB2BGR))
    x1, y1, x2, y2 = faces[0].bbox
    fh = y2 - y1

    r, g, b = arr[..., 0], arr[..., 1], arr[..., 2]
    skin = (r > 70) & (r < 245) & (r - g > 10) & (g - b > 8) & (r - b > 20)
    bg = (r > 235) & (g > 235) & (b > 235)

    # Shoulder line: first row below chin where >35% of the person-width
    # band (x1-0.3fh .. x2+0.3fh) is non-skin AND non-background (shirt).
    lo = max(0, int(x1 - fh * 0.30))
    hi = min(w, int(x2 + fh * 0.30))
    shoulder = None
    for y in range(int(y2), h):
        band = ~(skin[y, lo:hi] | bg[y, lo:hi])
        if band.mean() > 0.35:
            shoulder = y
            break

    # Collar V bottom (centre): last row where central 10% is skin below chin.
    c0, c1 = int(w * 0.45), int(w * 0.55)
    last_skin = None
    for y in range(int(y2), h):
        if skin[y, c0:c1].mean() > 0.6:
            last_skin = y

    neck_px = (shoulder - y2) if shoulder else None
    print(
        f"{name}: chin={y2:.0f} shoulder={shoulder} neck_len={neck_px} "
        f"({neck_px / fh:.2f}x fh) centre_skin_to={last_skin} "
        f"face_h={fh:.0f} ({fh/h:.3f}h)"
    )
    return int(y2), shoulder, fh


for name, fname in (
    ("src", f"{JOB}_person_qwen_input.png"),
    ("raw", f"{JOB}_qwen_raw.png"),
    ("lock", f"{JOB}_post_identity_lock.png"),
    ("ab", "_ab_baseline.png"),
):
    analyse(name, OUT / fname)

# Map head-lock paste boundary precisely: rows where lock differs from raw.
raw = np.asarray(Image.open(OUT / f"{JOB}_qwen_raw.png").convert("RGB")).astype(int)
lock = np.asarray(Image.open(OUT / f"{JOB}_post_identity_lock.png").convert("RGB")).astype(int)
h, w = raw.shape[:2]
d = (np.abs(raw - lock).max(axis=2) > 8)[:, int(w * 0.40):int(w * 0.60)]
frac = d.mean(axis=1)
rows = [y for y in range(int(h * 0.35), int(h * 0.75)) if frac[y] > 0.10]
# contiguous runs
runs = []
if rows:
    s = p = rows[0]
    for y in rows[1:]:
        if y - p > 3:
            runs.append((s, p))
            s = y
        p = y
    runs.append((s, p))
print("\ncentral-column paste runs (lock != raw):", runs)
